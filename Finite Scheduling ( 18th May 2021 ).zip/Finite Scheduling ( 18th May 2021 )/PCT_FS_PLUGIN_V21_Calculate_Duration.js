/**
 * @NApiVersion 2.1
 * @NModuleScope Public
 * @NScriptType plugintypeimpl
 */
 define(['N/log', 'N/search','SuiteScripts/Finite Scheduling/Library/moment.min.js'], function (log, search, moment) {
  /**
  *
  * @param pluginContext
  * @param {String} pluginContext.unsignedString
  * @param {String} plugincontext.subsidiaryId
  *
  * @returns {Object} result
  * @returns {string} result.success
  * @returns {String} result.signedString
  * @returns {String} result.message
  */
  var end_date = '';
  var work_ctr_end_time = new Array();

  function calculateDuration(Tasks, time_send, ReciveStartTime, ReciveEndTime) {
    ReciveStartTime = '08:00 AM';
    ReciveEndTime = '05:00 PM';
    var manufacturingoperationtaskSearchObj = search.create({
      type: "manufacturingoperationtask",
      filters:
        [
          ["status", "anyof", "PROGRESS", "NOTSTART"],
          "AND",
          ["workorder.status", "anyof", "WorkOrd:A", "WorkOrd:B"],
          "AND",
          ["workorder.datecreated", "onorafter", "lastyeartodate"]
        ],
      columns:
        [
          search.createColumn({
            name: "manufacturingworkcenter",
            summary: "GROUP",
            label: "Manufacturing Work Center"
          })
        ]
    });

    var searchResultCount = manufacturingoperationtaskSearchObj.runPaged().count;
    log.debug("manufacturingoperationtaskSearchObj result count", searchResultCount);
    if (searchResultCount > 0) {
      manufacturingoperationtaskSearchObj.run().each(function (result) {
        // .run().each has a limit of 4,000 results
        var wrk_ctr = result.getValue({ name: "manufacturingworkcenter", summary: "GROUP" });
        /*log.debug({
          title: 'PCT-LOG',
          details: "Work Center = "+wrk_ctr
        });*/
        work_ctr_end_time[wrk_ctr] = '';
        return true;
      });
    }

    var task_details = JSON.stringify(Tasks);
    log.debug({
      title: 'PCT-FS-CP',
      details: "Task Details = " + task_details
    });
    var completed_task = new Array();

    for (var i = 0; i < Tasks.length; i++) {
      var internalId = Tasks[i].InternalId;
      log.debug({
        title: 'PCT-FS-CP',
        details: "check i " + i
      });
      // log.debug({
      //   title: 'PCT-LOG',
      //   details: 'Whole task = '+JSON.stringify(Tasks[i])
      // })
      // log.debug({
      //   title: 'PCT-LOG',
      //   details: 'Internal ID = '+internalId
      // })
      // log.debug({
      //   title: 'PCT-LOG',
      //   details: 'Machine Only= '+ Tasks[i].Machine
      // });
      // log.debug({
      //   title: 'PCT-LOG',
      //   details: 'work_ctr_end_time Only= '+ work_ctr_end_time
      // });
      // log.debug({
      //   title: 'PCT-LOG',
      //   details: 'Machine ID = '+ work_ctr_end_time[Tasks[i].Machine]
      // });
      if (end_date == '' || work_ctr_end_time[Tasks[i].Machine] == '') {
        log.debug({
          title: 'PCT-FS-CP',
          details: "Recive date=" + time_send
        });
        if (time_send == '') {
          var current_date = new Date();
          //nlapiLogExecution('debug', 'CTP-log', 'Current Date='+current_date);
          current_date = (current_date.getMonth() + 1) + "/" + current_date.getDate() + "/" + current_date.getFullYear() + " " + ReciveStartTime;
          // nlapiLogExecution('debug', 'CTP-log', 'Current Date='+current_date);
        } else {
          var current_date = time_send + ' ' + ReciveStartTime;
          //nlapiLogExecution('debug', 'CTP-log', 'Current Date='+current_date);
          //var cur_date =  (current_date.getMonth() + 1) + "/" + current_date.getDate() + "/" + current_date.getFullYear();
          //nlapiLogExecution('debug', 'CTP-log', 'cur_date ='+cur_date);
        }
        if (Tasks[i].PInternalId != -1) {
          log.debug({
            title: 'EndDate 1=',
            details: "check Enddate "
          });
          var current_date = completed_task[i - 1].EndDate;
        }
      } else {
        if (Tasks[i].PInternalId == -1) {
          var current_date = work_ctr_end_time[Tasks[i].Machine];
        } else if (Tasks[i].PInternalId != -1) {
          log.debug({
            title: 'EndDate 2=',
            details: "check machine=" + Tasks[i].Machine
          });

          log.debug({
            title: 'EndDate 2=',
            details: "check Enddate pred=" + Tasks[i].PInternalId
          });
          var prev_end_date = new Date(completed_task[i - 1].EndDate);
          var wrk_str_time = new Date(work_ctr_end_time[Tasks[i].Machine]);
          var prev_end_date_ts = prev_end_date.getTime();
          var wrk_str_time_ts = wrk_str_time.getTime();

          if (prev_end_date_ts > wrk_str_time_ts) {
            log.debug({
              title: 'EndDate 3=',
              details: "check Enddate "
            });
            var current_date = completed_task[i - 1].EndDate;
          } else {
            var current_date = work_ctr_end_time[Tasks[i].Machine];
          }
          //nlapiLogExecution('debug', 'CTP-log', 'PCT Current Date=' + current_date + 'previous end=' + completed_task[i - 1].EndDate + 'wrk crt end=' + work_ctr_end_time[Tasks[i].Machine]);
        }
        //nlapiLogExecution('debug', 'CTP-log', 'PCT Current Date='+current_date);
      }
      var duration = Tasks[i].Duration;

      var opName = Tasks[i].OperationName;

      log.debug({
        title: 'opName',
        details: "opName = " + opName
      });

      //nlapiLogExecution('debug', 'CTP-log', 'Time Duration='+duration);
      end_date = AddWorkDayMinutes(current_date, duration, ReciveStartTime, ReciveEndTime);
      work_ctr_end_time[Tasks[i].Machine] = end_date;
      //nlapiLogExecution('debug', 'CTP-log', 'End Date='+end_date);
      var job_end_date = new Date(AddWorkDayMinutes(current_date, duration, ReciveStartTime, ReciveEndTime));
      var current_end_date = (job_end_date.getMonth() + 1) + "/" + job_end_date.getDate() + "/" + job_end_date.getFullYear();
      //nlapiLogExecution('debug', 'CTP-log', 'Job End Date='+current_end_date);

      //added for downtime
      var downtime = new Array();

      var curr_date = new Date(current_date);

      var setup_clcok_hours = curr_date.getHours();
      var setup_clock_minutes = curr_date.getMinutes();

      var setup_clcok_sec = curr_date.getSeconds();
      var setup_ampm = setup_clcok_hours >= 12 ? 'pm' : 'am';
      setup_clcok_hours = setup_clcok_hours % 12;
      setup_clcok_hours = setup_clcok_hours ? setup_clcok_hours : 12; // the hour '0' should be '12'
      setup_clock_minutes = setup_clock_minutes < 10 ? '0' + setup_clock_minutes : setup_clock_minutes;
      //var current_setup_seconds = "00";
      var setup_strTime = (curr_date.getMonth() + 1) + "/" + curr_date.getDate() + "/" + curr_date.getFullYear() + " " + setup_clcok_hours + ':' + setup_clock_minutes + ' ' + setup_ampm;

      log.debug({
        title: 'setup_strTime',
        details: "setup_strTime = " + setup_strTime
      });

      log.debug({
        title: 'job_end_date',
        details: "job_end_date = " + job_end_date
      });

      // nlapiLogExecution('DEBUG','PCT_log','setup_clcok_sec='+setup_strTime);

      var customrecord_pct_fs_work_block_dataSearchObj = search.create({
        type: "customrecord_pct_fs_work_block_data",
        filters:
          [
            ["custrecord_pct_fs_wrk_center_name", "is", opName],
            "AND",
            ["custrecord_pct_fs_downtime_start_time", "within", setup_strTime, end_date]
          ],
        columns:
          [
            search.createColumn({ name: "custrecord_pct_fs_wrk_center_name", label: "Operation Name" }),
            search.createColumn({ name: "custrecord_pct_fs_downtime_start_time", label: "Downtime Start Time" }),
            search.createColumn({ name: "custrecord_pct_fs_downtime_end_time", label: "Downtime End Time" }),
            search.createColumn({ name: "custrecord_pct_fs_dwn_time_duration", label: "Downtime Duration" })
          ]
      });
      var searchResultCount = customrecord_pct_fs_work_block_dataSearchObj.runPaged().count;
      log.debug("customrecord_pct_fs_work_block_dataSearchObj result count", searchResultCount);
      var down_duration = 0;
      if (searchResultCount > 0) {
        customrecord_pct_fs_work_block_dataSearchObj.run().each(function (result) {
          // .run().each has a limit of 4,000 results
          var down_start = result.getValue({ name: "custrecord_pct_fs_downtime_start_time" });
          var down_end = result.getValue({ name: "custrecord_pct_fs_downtime_end_time" });
          var block_duration = result.getValue({ name: "custrecord_pct_fs_dwn_time_duration" });
          down_duration = parseInt(down_duration) + parseInt(block_duration);

          downtime.push({
            downStart: down_start,
            downEnd: down_end
          });

          return true;
        });

        end_date = AddWorkDayMinutes(job_end_date, down_duration, ReciveStartTime, ReciveEndTime);
        var endCheck_date = new Date(AddWorkDayMinutes(job_end_date, down_duration, ReciveStartTime, ReciveEndTime));
        current_end_date = (endCheck_date.getMonth() + 1) + "/" + endCheck_date.getDate() + "/" + endCheck_date.getFullYear();
      }

      //end downtime
      log.debug({
        title: "PCT-FS",
        details: "Complete Task Details : Internal ID:" + internalId + "Current End Date :" + current_end_date + "Current Date : " + current_date + "End Date : " + end_date + "Downtime Duration :" + down_duration + "Downtime" + downtime
      });

      completed_task.push({
        JInternalId: internalId,
        JEndDate: current_end_date,
        StartDate: current_date,
        EndDate: end_date,
        currentDowntimeDuration: down_duration,
        downtime: downtime
      });
      
        
        var check = new Array();

        check.push({
            JInternalId: internalId,
            JEndDate: current_end_date,
            StartDate: current_date,
            EndDate: end_date,
            currentDowntimeDuration: down_duration,
            downtime: downtime
          });
        
      log.debug({
        title: 'PCT FS CP=',
        details: "Completed last startdate = " + current_date +" End date= " +end_date
      });
      
      log.debug({
        title: 'PCT FS CP=',
        details: "Completed last startdate = " + JSON.stringify(check)
      });
      log.debug({
        title: 'PCT FS CP=',
        details: "Completed Task = " + JSON.stringify(completed_task)
      });

    }
    log.debug({ title: 'PCT-FS', details: 'Completed Task' + completed_task.length });
    return completed_task;
  }

  function gantt_structure(chart_data) {
    log.debug({
      title: 'PCT-FS-CP-GC',
      details: "Chart Data" + JSON.stringify(chart_data)
    });
    var gantt_data = new Array();
    var gnattSeriesArray = new Array();
    var chartDataLength = chart_data.length;
    var current_id = '';
    var workcenter_id = new Array();

    for (var j = 0; j < chartDataLength; j++) {
      workcenter_id[j] = chart_data[j].wcid;
    }

    var unique_wc = new Array();
    var unique_color = new Array();
    unique_wc = getUnique(workcenter_id);
    log.debug({
      title: 'PCT-FS-CP-GC',
      details: 'unique_wc =' + unique_wc
    });
    log.debug({
      title: 'PCT-FS-CP-GC',
      details: 'unique_wc len=' + unique_wc.length
    });

    for (var k = 0; k < unique_wc.length; k++) {
      unique_color[k] = "#000000".replace(/0/g, function () {
        return (~~(Math.random() * 16)).toString(16);
      });
    }

    log.debug({
      title: 'PCT-FS-CP-GC',
      details: 'unique_color =' + unique_color
    });
    log.debug({
      title: 'PCT-FS-CP-GC',
      details: 'unique_color len=' + unique_color.length
    });
    for (var index = 0; index < chartDataLength; index++) {
      var gnatt_record = new Object();
      var gnatt_record_series = new Object();
      var id = chart_data[index].id;
      var name = chart_data[index].wrkid;
      var operation_id = chart_data[index].operation_id;
      var operationn_ame = chart_data[index].operation;
      var workcenter = chart_data[index].wcid;
      var workcenter = chart_data[index].wcid;
      var downtime = chart_data[index].downtime;
      var start = 'new Date("' + chart_data[index].ssdt + '")';
      var end = 'new Date("' + chart_data[index].sedt + '")';
      var randomColor;

      /*var randomColor = "#000000".replace(/0/g, function () {
        return (~~(Math.random() * 16)).toString(16);
      });*/
      for (var l = 0; l < unique_color.length; l++) {
        if (workcenter == unique_wc[l]) {
          randomColor = unique_color[l];
        }
      }

      if (index == 0) {
        gnatt_record['id'] = id;
        gnatt_record['name'] = name;
        gnatt_record_series['id'] = operation_id;
        gnatt_record_series['name'] = operationn_ame;
        gnatt_record_series['start'] = start;
        gnatt_record_series['end'] = end;
        gnatt_record_series['color'] = randomColor;
        gnatt_record_series['downtime'] = downtime;
        gantt_data.push(gnatt_record);
        gnattSeriesArray.push(gnatt_record_series);
        log.debug({
          title: 'PCT-FS-CP-GC',
          details: 'Gnatt Record:' + gnatt_record
        });
        current_id = id;
      } else {
        if (current_id == id) {
          gnatt_record_series['id'] = operation_id;
          gnatt_record_series['name'] = operationn_ame;
          gnatt_record_series['start'] = start;
          gnatt_record_series['end'] = end;
          gnatt_record_series['color'] = randomColor;
          gnatt_record_series['downtime'] = downtime;
          gnattSeriesArray.push(gnatt_record_series);
          if (parseInt(index) == parseInt(chartDataLength - 1)) {
            var gnattDataIndex = gantt_data.map(function (o) {
              return o.id;
            }).indexOf(current_id);
            log.debug({
              title: 'PCT-FS-CP-GC',
              details: 'Gnatt Data Index:' + gnattDataIndex
            });
            log.debug({
              title: 'PCT-FS-CP-GC',
              details: 'Gnatt Series Array:' + gnattSeriesArray
            });

            gantt_data[gnattDataIndex]['series'] = gnattSeriesArray;
          }
        } else {
          var gnattDataIndex = gantt_data.map(function (o) {
            return o.id;
          }).indexOf(current_id);
          gantt_data[gnattDataIndex]['series'] = gnattSeriesArray;
          gnattSeriesArray = [];
          gnatt_record['id'] = id;
          gnatt_record['name'] = name;
          gnatt_record_series['id'] = operation_id;
          gnatt_record_series['name'] = operationn_ame;
          gnatt_record_series['start'] = start;
          gnatt_record_series['end'] = end;
          gnatt_record_series['color'] = randomColor;
          gnatt_record_series['downtime'] = downtime;
          gantt_data.push(gnatt_record);
          gnattSeriesArray.push(gnatt_record_series);
          current_id = id;
          if (parseInt(index) == parseInt(chartDataLength - 1)) {
            log.debug({
              title: 'PCT-FS-CP-GC',
              details: '2'
            });
            var gnattDataIndex = gantt_data.map(function (o) {

              return o.id;
            }).indexOf(current_id);
            log.debug({
              title: 'PCT-FS-CP-GC',
              details: 'Gnatt Data Index:' + gnattDataIndex
            });
            log.debug({
              title: 'PCT-FS-CP-GC',
              details: 'Gnatt Series Array:' + gnattSeriesArray
            });

            gantt_data[gnattDataIndex]['series'] = gnattSeriesArray;

          }
        }
      }
    }
    return gantt_data;
  }
  function showTimeIntervals(value) {
    var returnData = new Array();
    var result = value.interval.split(","); 
    var start = "";
    var timeNotation = '';
    var time = '';
    for(var i in result) {
      var hr = moment(result[i], 'HH:mm').format('HH');
      var min = moment(result[i], 'HH:mm').format('mm');
      hr = (hr != 0) ? parseInt(hr, 10) : '';
      min = (min != 0) ? parseInt(min, 10) : '';
      if(hr != 0) {
        time = hr;
        timeNotation = 'hour';
        start = moment(value.startTime, 'hh:mm a');
      } else {
        time = min;
        timeNotation = 'minutes';
        start = moment(value.startTime, 'hh:mm a').subtract(min, 'minutes');
      }
    }
    var end = moment(value.endTime, 'hh:mm a');
    if(end < start)
      end = end.add(1, 'd');
    var finalResult = [];
    var current = moment(start);
    while (current < end) {
    var currentTime = current.format('hh:mm a');
    currentTime = getTwentyFourHourTime(currentTime);
      returnData.push('"'+currentTime+'"');
      current.add(time, timeNotation);
    }
    return returnData;
  }
  return {
    calculateDuration: calculateDuration,
    gantt_structure: gantt_structure,
    showTimeIntervals: showTimeIntervals
  }
});

function diff_minutes(dt2, dt1) {

  var diff = (dt2.getTime() - dt1.getTime()) / 1000;
  diff /= 60;
  return Math.round(diff);

}

function add_minutes(dt, minutes) {
  return new Date(dt.getTime() + minutes * 60000);
}

function formatDate(date) {
  var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2)
    month = '0' + month;
  if (day.length < 2)
    day = '0' + day;

  return [month, day, year].join('/');
}

function AddWorkDayMinutes(date, minutes, customStartTime, customEndTime) {
  //StartTimes=["12:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","12:00:00 AM"]
  //EndTimes=["12:00:00 AM","5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM","12:00:00 AM"]
  var StartTimes = new Array();
  var EndTimes = new Array();
  StartTimes.push("12:00 AM");
  EndTimes.push("12:00 AM");
  for (var timeIndex = 0; timeIndex < 5; timeIndex++) {
    StartTimes.push(customStartTime);
    EndTimes.push(customEndTime);
  }
  StartTimes.push("12:00 AM");
  EndTimes.push("12:00 AM");

  var inDate = new Date(date);
  var retDate = inDate;
  var MinsLeft = minutes;
  while (MinsLeft > 0) {
    //alert(inDate)
    var CurrDate = inDate;
    var dayIndex = CurrDate.getDay();
    var CurrStartDateTime = new Date(formatDate(CurrDate) + ' ' + StartTimes[dayIndex]);
    var CurrEndDateTime = new Date(formatDate(CurrDate) + ' ' + EndTimes[dayIndex]);

    var diffMins = diff_minutes(CurrEndDateTime, CurrDate);

    var AvailableMinutesToday = (diffMins < 0 ? 0 : diffMins);


    if (diffMins > 540) {
      AvailableMinutesToday = 540;

    }

    var workfortoday = diff_minutes(CurrEndDateTime, CurrStartDateTime);

    if (MinsLeft <= AvailableMinutesToday) {

      if (diffMins > 540) {
        retDate = add_minutes(CurrStartDateTime, MinsLeft);
      } else {
        retDate = add_minutes(CurrDate, MinsLeft);
      }

      break;

    }
    if (MinsLeft <= workfortoday) {
      retDate = add_minutes(CurrStartDateTime, MinsLeft);

    }

    MinsLeft -= AvailableMinutesToday;

    inDate.setDate(inDate.getDate() + 1);
    var newIndate = new Date(formatDate(inDate) + ' ' + StartTimes[inDate.getDay()]);

    inDate = newIndate;
  }

  var next_hours = retDate.getHours();
  var next_minutes = retDate.getMinutes();
  var ampm = next_hours >= 12 ? 'pm' : 'am';
  next_hours = next_hours % 12;
  next_hours = next_hours ? next_hours : 12; // the hour '0' should be '12'
  next_minutes = next_minutes < 10 ? '0' + next_minutes : next_minutes;
  var next_date_time = (retDate.getMonth() + 1) + "/" + retDate.getDate() + "/" + retDate.getFullYear() + " " + next_hours + ':' + next_minutes + ' ' + ampm;

  return next_date_time;
}
function getUnique(array) {
  var uniqueArray = new Array();

  // Loop through array values
  for (index = 0; index < array.length; index++) {
    if (uniqueArray.indexOf(array[index]) === -1) {
      uniqueArray.push(array[index]);
    }
  }
  return uniqueArray;
}
function getTwentyFourHourTime(amPmString) { 
  var d = new Date("1/1/2013 " + amPmString);
  var hours = d.getHours();
  if(parseInt(hours) == 0)
  {
    hours += '0'; 
  }
  return hours; 
}
