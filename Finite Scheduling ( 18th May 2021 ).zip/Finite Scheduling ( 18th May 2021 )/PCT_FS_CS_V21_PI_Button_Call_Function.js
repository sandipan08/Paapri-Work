/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
define(["N/url", "N/https", "N/search", "N/currentRecord"], function (url, https, search, currentRecord)
{
    function pageInit(context)
    {
        var method = context.currentRecord.getValue({ fieldId: 'custpage_get_method' });

        var recordDataItem = context.currentRecord.getValue({ fieldId: 'custpage_item_store' });
        var recordDataDate = context.currentRecord.getValue({ fieldId: 'custpage_date_store' });
        var recordDataQty = context.currentRecord.getValue({ fieldId: 'custpage_quantity_store' });
        var recordDataST = context.currentRecord.getValue({ fieldId: 'custpage_starttime_store' });
        var recordDataET = context.currentRecord.getValue({ fieldId: 'custpage_endtime_store' });
        var recordmovefirst = context.currentRecord.getValue({ fieldId: 'custpage_movefirst_store' });
        
        if (recordDataItem == '' || recordDataItem == null)
        {
            recordDataItem = null
        }

        if(method == 'POST')
        {
            jQuery("#confirmschl").removeClass('d-none');
        }
        // document.getElementById("assemblyItemList").value = "Johnny Bravo";
        console.log('Date = ' + recordDataDate)
        console.log('Item = ' + recordDataItem);
        console.log('Qty = ' + recordDataQty);
        console.log('Start_Time = ' + recordDataST);
        console.log('End_Time = ' + recordDataET);
        var AssemblyItemSearch = search.create({
            type: "assemblyitem",
            filters: [
                ["type", "anyof", "Assembly"]
            ],
            columns: [
                search.createColumn({
                    name: "itemid",
                    sort: search.Sort.ASC,
                    label: "Name"
                })
            ]
        });
        var AssemblyItemCount = AssemblyItemSearch.runPaged().count;
        var AssemblyItemResult = AssemblyItemSearch.run().getRange({
            start: 0,
            end: AssemblyItemCount
        });
        var itemDataList = '<option></option>';
        if (AssemblyItemCount > 0)
        {
            for (var AssemblyItem_Index = 0; AssemblyItem_Index < AssemblyItemCount; AssemblyItem_Index++)
            {
                var itemId = AssemblyItemResult[AssemblyItem_Index].id;
                var itemName = AssemblyItemResult[AssemblyItem_Index].getValue({ name: 'itemid' });
                itemDataList += '<option value="' + itemId + '">' + itemName + '</option>';
                console.log('itemId = ' + itemId);
            }
        }
        jQuery('#assemblyItemList').append(itemDataList);
        console.log('Assembly Data:' + itemDataList);
        var recordData = context.currentRecord.getValue({ fieldId: 'custpage_pctrecordarray' });
        console.log('Data Record:' + recordData);
        recordData = JSON.parse(recordData);
        var recordLength = recordData.length;
        var tableRecordDate = '<table id="scheduleTable" class="table table-striped table-bordered" style="width:100%">' +
            '                        <thead>' +
            '                            <tr>' +
            '                                <th>WORK ORDER</th>' +
            '                                <th>OPERATION SEQUENCE</th>' +
            '                                <th>OPERATION</th>' +
            '                                <th>PREDECESSOR</th>' +
            '                                <th>WORK CENTER</th>' +
            '                                <th>TIME TO COMPLETE</th>' +
            '                                <th>PLAN START DATE</th>' +
            '                                <th>PLAN END DATE</th>' +
            '                                <th>SCHEDULE START DATE</th>' +
            '                                <th>SCHEDULE END DATE</th>' +
            '                                <th>PRIORITY</th>' +
            '                            </tr>' +
            '                        </thead>' +
            '                        <tbody>';
        for (var iterate_recordData = 0; iterate_recordData < recordData.length; iterate_recordData++)
        {
            var id = recordData[iterate_recordData].id;
            var wrkid = recordData[iterate_recordData].wrkid;
            var operation_id = recordData[iterate_recordData].operation_id;
            var operation = recordData[iterate_recordData].operation;
            //var operation_name= recordData[iterate_recordData].getText({ name: 'operation' });
            var predecessor = recordData[iterate_recordData].pred;
            var wcid = recordData[iterate_recordData].wcid;
            var ttc = recordData[iterate_recordData].ttc;
            var psdt = recordData[iterate_recordData].psdt;
            var pedt = recordData[iterate_recordData].pedt;
            var ssdt = recordData[iterate_recordData].ssdt;
            var sedt = recordData[iterate_recordData].sedt;
            var wrkpr = recordData[iterate_recordData].wrkpr;
            var opseq = recordData[iterate_recordData].opseq;
            if(typeof (opseq) === "undefined")
            {
                opseq = '';
            }
            if(typeof (wrkpr) === "undefined")
            {
                wrkpr = 0;
            }
            tableRecordDate += '<tr>' +
                '                                <td>' + wrkid + '</td>' +
                '                                <td>' + opseq + '</td>' +
                '                                <td>' + operation + '</td>' +
                '                                <td>' + predecessor + '</td>' +
                '                                <td>' + wcid + '</td>' +
                '                                <td>' + ttc + '</td>' +
                '                                <td>' + psdt + '</td>' +
                '                                <td>' + pedt + '</td>' +
                '                                <td>' + ssdt + '</td>' +
                '                                <td>' + sedt + '</td>' +
                '                                <td>' + wrkpr + '</td>' +
                '                            </tr>';
        }
        var myvar = '</tbody>' +
            '                    </table>';
        jQuery('#scheduleDataTable').html(tableRecordDate);
        jQuery('#scheduleTable').DataTable({
            "order": [[10, 'desc']],
            //"scrollY": "200px",
            "scrollCollapse": false,
            "paging": false,
            "lengthChange": false,
            "pagingType": "first_last_numbers",
            retrieve: true,
            "pageLength": 10000,
            "processing": true,
            "language": {
                "emptyTable": "No workorder(s) found",
                "infoEmpty": ""
            },
            preDrawCallback: function (settings)
            {
                var api = new $.fn.dataTable.Api(settings);
                $(this).closest('.dataTables_wrapper').find('.dataTables_paginate').toggle(api.page.info().pages > 1);
            }
        });


        jQuery('#assemblyItemList option[value=' + recordDataItem + ']').prop('selected', true);
        jQuery("#pwd").val(recordDataDate);
        jQuery("#quantity").val(recordDataQty);
       
        jQuery("#starttimeinput").val('08:00 AM');
        jQuery("#endtimeinput").val('05:00 PM');

     
        jQuery("#movefirst").val(recordmovefirst);

        jQuery("#starttimeinput").prop('disabled', true);
        jQuery("#endtimeinput").prop('disabled', true);

    }
    return {
        pageInit: pageInit,
    };
});