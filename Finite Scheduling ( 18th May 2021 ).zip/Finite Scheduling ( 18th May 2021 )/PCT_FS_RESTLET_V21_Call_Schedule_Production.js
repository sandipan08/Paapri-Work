/**
 *@NApiVersion 2.1
 *@NScriptType Restlet
 */
define(["N/task", "N/search", "N/log", 'N/file'], function (task, search, log, file) {

    function _get(context) {
        log.debug({
            title: 'PCT-FS',
            details: 'Running'
        });
        var file_id;
        var fileSearchObj = search.create({
            type: "file",
            filters:
                [
                    ["filetype", "anyof", "JSON"],
                    "AND",
                    ["name", "haskeywords", "FiniteSchedulingData"]
                ],
            columns:
                [
                    search.createColumn({ name: "internalid", label: "Internal ID" })
                ]
        });
        var searchResultCount = fileSearchObj.runPaged().count;
        log.debug("fileSearchObj result count", searchResultCount);
        fileSearchObj.run().each(function (result) {
            // .run().each has a limit of 4,000 results
            file_id = result.getValue({ name: "internalid" });
            return true;
        });

        log.debug({
            title: 'PCT-FS',
            details: 'File ID' + file_id
        });
        //var file_id = 7697;

        var job = task.create({
            taskType: task.TaskType.MAP_REDUCE,
            scriptId: 'customscript_pct_fs_mpv21_schedule_data',
            deploymentId: 'customdeploy_pct_fs_mpv21_schedule_data',
            params: { 'custscript_pct_fs_mapreduce_param': file_id }
        });
        job.submit();
        log.debug({
            title: 'PCT-log',
            details: 'Success'
        });
    }

    function _post(datain) {
        var retrievedData = datain;
        log.debug({
            title: 'PCT-log',
            details: 'Modified JSON Data = ' + retrievedData
        });
        var fileObj = file.create({
            name: 'data.json',
            fileType: file.Type.JSON,
            contents: retrievedData
        });
        var mainFolderId = 0;
        var mainFolderSearch = search.create({
            type: "folder",
            filters:
                [
                    ["name", "is", "Finite Scheduling"]
                ]
        });
        var mainFolderSearchCount = mainFolderSearch.runPaged().count;
        log.debug("PCT-FS", 'Main Folder Count:' + mainFolderSearchCount);
        var mainFolderSearchResult = mainFolderSearch.run().getRange({
            start: 0,
            end: mainFolderSearchCount
        });
        if (mainFolderSearchCount > 0) {
            for (var mainFolderIndex = 0; mainFolderIndex < mainFolderSearchCount; mainFolderIndex++) {
                mainFolderId = mainFolderSearchResult[mainFolderIndex].id;
                log.debug({
                    title: 'PCT-FS',
                    details: 'Main Folder Id:' + mainFolderId
                });
            }
        }
        if (mainFolderId > 0) {
            var dataFolderId = 0;
            var dataFolderSearch = search.create({
                type: "folder",
                filters:
                    [
                        ["name", "is", "Gnatt Data"],
                        "AND",
                        ["parent", "anyof", mainFolderId]
                    ]
            });
            var dataFolderSearchCount = dataFolderSearch.runPaged().count;
            log.debug("PCT-FS", 'Data Folder Count:' + dataFolderSearchCount);
            var dataFolderSearchResult = dataFolderSearch.run().getRange({
                start: 0,
                end: dataFolderSearchCount
            });
            if (dataFolderSearchCount > 0) {
                for (var dataFolderIndex = 0; dataFolderIndex < dataFolderSearchCount; dataFolderIndex++) {
                    dataFolderId = dataFolderSearchResult[dataFolderIndex].id;
                    log.debug({
                        title: 'PCT-FS',
                        details: 'Data Folder Id:' + dataFolderId
                    });
                }
            }
            if (dataFolderId > 0) {
                fileObj.folder = dataFolderId;
                var fileId = fileObj.save();
                log.debug({
                    title: 'PCT-FS',
                    details: 'Updated File Id:' + fileId
                });
                var job = task.create({
                    taskType: task.TaskType.MAP_REDUCE,
                    scriptId: 'customscript_pct_fs_mpv21_schedule_data',
                    deploymentId: 'customdeploy_pct_fs_mpv21_schedule_data',
                    params: { 'custscript_pct_fs_mapreduce_param': fileId }
                });
                job.submit();
            }
        }
        return 'Data Successfully Updated';
    }
    return {
        get: _get,
        post: _post
    };
});