/*
jQuery.ganttView v.0.8.8
Copyright (c) 2010 JC Grubbs - jc.grubbs@devmynd.com
MIT License Applies
*/

/*
Options
-----------------
showWeekends: boolean
data: object
cellWidth: number
cellHeight: number
slideWidth: number
dataUrl: string
behavior: {
	clickable: boolean,
	draggable: boolean,
	resizable: boolean,
	onClick: function,
	onDrag: function,
	onResize: function
}
*/

(function (jQuery) {

	jQuery.fn.ganttView = function () {

		var args = Array.prototype.slice.call(arguments);

		if (args.length == 1 && typeof(args[0]) == "object") {
			build.call(this, args[0]);
		}

		if (args.length == 2 && typeof(args[0]) == "string") {
			handleMethod.call(this, args[0], args[1]);
		}
	};

	/*----------------------------------------DEFINING MONTH NAMES AND WORKHOURS----------------------------------------*/

	var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	//console.log("workHours = " + workHours);
	var hours = ["8","9","10","11","12","13","14","15","16"];
	var numberOfHours = hours.length;
	var blockStore = new Array();

	/*----------------------------------------DEFINING MONTH NAMES AND WORKHOURS----------------------------------------*/

	function build(options) {

		var els = this;
		var defaults = {
			showWeekends: true,
			cellWidth: 21,
			cellHeight: 31,
			slideWidth: 400,
			vHeaderWidth: 100,
			behavior: {
				clickable: true,
				draggable: true,
				resizable: true
			}
		};

		var opts = jQuery.extend(true, defaults, options);

		if (opts.data) {
			build();
		} else if (opts.dataUrl) {
			jQuery.getJSON(opts.dataUrl, function (data) { opts.data = data; build(); });
		}

		function build() {
			hours = opts.hours;
			numberOfHours = hours.length;
			console.log("hours: " + hours[2]);
			var minDays = Math.floor((opts.slideWidth / opts.cellWidth)  + 5);
			var startEnd = DateUtils.getBoundaryDatesFromData(opts.data, minDays);
			opts.start = startEnd[0];
			console.log("opts.start=" + opts.start);
			opts.end = startEnd[1].clone();
			opts.end.addDays(180);

			els.each(function () {

				var container = jQuery(this);
				var div = jQuery("<div>", { "class": "ganttview" });
				new Chart(div, opts).render();
				container.append(div);

				var w = jQuery("div.ganttview-vtheader", container).outerWidth() +
				jQuery("div.ganttview-slide-container", container).outerWidth();
				container.css("width", (w + 2) + "px");

				new Behavior(container, opts).apply();
			});
		}
	}

	function handleMethod(method, value) {

		if (method == "setSlideWidth") {
			var div = $("div.ganttview", this);
			div.each(function () {
				var vtWidth = $("div.ganttview-vtheader", div).outerWidth();
				$(div).width(vtWidth + value + 1);
				$("div.ganttview-slide-container", this).width(value);
			});
		}
	}

	var Chart = function(div, opts) {

		function render() {
			addVtHeader(div, opts.data, opts.cellHeight);

			var slideDiv = jQuery("<div>", {
				"class": "ganttview-slide-container",
				"css": { "width": opts.slideWidth + "px" }
			});

			dates = getDates(opts.start, opts.end);
			addHzHeader(slideDiv, dates, opts.cellWidth);
			addGrid(slideDiv, opts.data, dates, opts.cellWidth, opts.cellHeight, opts.showWeekends);
			addBlockContainers(slideDiv, opts.data);
			addBlocks(slideDiv, opts.data, opts.cellWidth, opts.start);
			div.append(slideDiv);
			applyLastClass(div.parent());
		}

		// Creates a 3 dimensional array [year][month][day] of every day 
		// between the given start and end dates
		function getDates(start, end) {
			var dates = [];
			dates[start.getFullYear()] = [];
			dates[start.getFullYear()][start.getMonth()] = [start]
			var last = start;
			while (last.compareTo(end) == -1) {
				var next = last.clone().addDays(1);
				if (!dates[next.getFullYear()]) { dates[next.getFullYear()] = []; }
				if (!dates[next.getFullYear()][next.getMonth()]) {
					dates[next.getFullYear()][next.getMonth()] = [];
				}
				dates[next.getFullYear()][next.getMonth()].push(next);
				last = next;
			}
			return dates;
		}

		function addVtHeader(div, data, cellHeight) {
			var headerDiv = $("<div>", { "class": "ganttview-vtheader" });
			div.append($("<div>", { "class": "ganttview-column-row-intersection" }));
			/*div.append($("<button>", { "class": "ganttview-confirm-button" }).append("Confirm"));*/

			for (var i = 0; i < data.length; i++) {
				var itemDiv = jQuery("<div>", { "class": "ganttview-vtheader-item" });
				itemDiv.append(jQuery("<div>", {
					"class": "ganttview-vtheader-item-name",
					"css": { "height": (data[i].series.length * cellHeight) + "px" }
				}).append(data[i].name));
				var seriesDiv = jQuery("<div>", { "class": "ganttview-vtheader-series" });
				for (var j = 0; j < data[i].series.length; j++) {
					seriesDiv.append(jQuery("<div>", { "class": "ganttview-vtheader-series-name" })
						.append(data[i].series[j].name));
				}
				itemDiv.append(seriesDiv);
				headerDiv.append(itemDiv);
			}
			headerDiv.append($("<div>", {
				"class": "ganttview-column-row-intersection",
				"css": { "position": "relative", "height": "7px" }
			}));
			div.append(headerDiv);
		}

		function addHzHeader(div, dates, cellWidth) {
			var headerDiv = jQuery("<div>", { "class": "ganttview-hzheader" });
			var monthsDiv = jQuery("<div>", { "class": "ganttview-hzheader-months" });
			var daysDiv = jQuery("<div>", { "class": "ganttview-hzheader-days" });
			var hoursDiv = jQuery("<div>", { "class": "ganttview-hzheader-hours" });			
			//var hours = ["8","9","10","11","12","13","14","15","16","17"];
			var totalW = 0;
			for (var y in dates) {
				for (var m in dates[y])
				{
					var w = 0;
					//totalW = totalW + w;
					for (var d in dates[y][m]) {
						var totalH = 0;
						hours.forEach(function(hour) {
							H = cellWidth;
							totalH = totalH + H;
							hoursDiv.append(jQuery("<div>", {
								"class": "ganttview-hzheader-hour",
								"css": { "width":(H -1) + "px" }
							}).append(hour));
						});
						var daysWidth = totalH;
						totalW = totalW + daysWidth; 
						w = w + daysWidth;
						daysDiv.append(jQuery("<div>", { 
							"class": "ganttview-hzheader-day",
							"css": { "width":(daysWidth - 1) +"px"}
						}).append(dates[y][m][d].getDate(), " "+monthNames[dates[y][m][d].getMonth()]));

					}
					monthsDiv.append(jQuery("<div>", {
						"class": "ganttview-hzheader-month",
						"css": { "width": (w - 1) + "px" }
					}).append(monthNames[m] + "/" + y));
				}
			}
			monthsDiv.css("width", totalW + "px");
			daysDiv.css("width", totalW + "px");
			hoursDiv.css("width", totalW + "px");
			var canvas = jQuery("<canvas>", { "class": "ganttview-arrow-canvas", "id": "ganttview-arrow-canvas", "width": "39312px", "height": "1536px"});
			headerDiv.append(monthsDiv).append(daysDiv).append(hoursDiv)/*.append(canvas)*/;
			div.append(headerDiv);
		}



		function addGrid(div, data, dates, cellWidth, cellHeight, showWeekends) {

			var gridDiv = jQuery("<div>", { "class": "ganttview-grid" });
			var rowDiv = jQuery("<div>", { "class": "ganttview-grid-row" });
		var canvas = jQuery("<canvas>", { "class": "ganttview-arrow-canvas", "id": "ganttview-arrow-canvas"/*, "width": "2267px", "height": "1536px"*/});
		var arrow = jQuery("<div>", { "class": "point" });

		for (var y in dates) {
			for (var m in dates[y]) {
				for (var d in dates[y][m]) {
					for(var k=0; k<numberOfHours;k++)
					{
						var cellDiv = jQuery("<div>", { "class": "ganttview-grid-row-cell" });
						if (DateUtils.isWeekend(dates[y][m][d]) && showWeekends) {
							cellDiv.addClass("ganttview-weekend");
						}
						rowDiv.append(cellDiv);
					}
				}
			}
		}

		var w = jQuery("div.ganttview-grid-row-cell", rowDiv).length * cellWidth;
		rowDiv.css("width", w + "px");
		gridDiv.css("width", w + "px");
		var h = 0;			
		for (var i = 0; i < data.length; i++) {
			for (var j = 0; j < data[i].series.length; j++) {
				gridDiv.append(rowDiv.clone());
				h += (cellHeight+1);
			}
		}
		console.log("h="+h);
		div.append(gridDiv);
		div.append(canvas);
		div.append(arrow);
	}

	function addBlockContainers(div, data) {
		var blocksDiv = jQuery("<div>", { "class": "ganttview-blocks" });
		for (var i = 0; i < data.length; i++) {
			for (var j = 0; j < data[i].series.length; j++) {
				blocksDiv.append(jQuery("<div>", { "class": "ganttview-block-container" }));
			}
		}
		div.append(blocksDiv);
	}

	function addBlocks(div, data, cellWidth, start) {
		var rows = jQuery("div.ganttview-blocks div.ganttview-block-container", div);
		var rowIdx = 0;
		var blockNumber = 0;
		var len = data.length;
		var seriesStartTime;
		for (var i = 0; i < len; i++)
		{
			var dataSeriesLength = data[i].series.length;
			for (var j = 0; j < dataSeriesLength; j++)
			{
				var series = data[i].series[j];

				seriesStartTime = series.start.clone();
				seriesStartTime.setMinutes(00);

				var size = Math.ceil(DateUtils.workDurationExcludingWeekends(seriesStartTime, series.end)/60);
				if(size < 0.5)
				{
					size = 0.5;
				}
				var duration = DateUtils.workDurationExcludingWeekends(series.start, series.end);
				var offset = Math.floor(DateUtils.workDurationIncludingWeekends(start, series.start)/60);

				var weekendCount = countWeekendDays(series.start, series.end);
				if(weekendCount%2 == 1)weekendCount++;
				size += (numberOfHours*weekendCount);

				var block = jQuery("<div>", {
					"class": "ganttview-block",
					"title": series.name + ", " + duration + "Minutes",
					"css": {
						"width": ((size * cellWidth) - 9) + "px",
						"margin-left": ((offset * cellWidth) + 3) + "px"
					}
				});
				addBlockData(block, data[i], i, j+1, blockNumber++, dataSeriesLength, series, offset);
				if (data[i].series[j].color) {
					block.css("background-color", data[i].series[j].color);
				}
				block.append(jQuery("<div>", { "class": "ganttview-block-text" }).text(duration));

				if(data[i].series[j].downtime)
				{
					var downtimeDataLength = data[i].series[j].downtime.length;
					if(downtimeDataLength > 0)
					{
						var downtimeData = data[i].series[j].downtime;

						for(var downtimeIndex = 0; downtimeIndex < downtimeDataLength; downtimeIndex++)
						{
							var downtimeBlockSize = (DateUtils.workDurationExcludingWeekends(downtimeData[downtimeIndex].downStart, downtimeData[downtimeIndex].downEnd)/60);
							var downtimeDuration = DateUtils.workDurationExcludingWeekends(downtimeData[downtimeIndex].downStart, downtimeData[downtimeIndex].downEnd);
							var downtimeOffset = (DateUtils.workDurationExcludingWeekends(start, downtimeData[downtimeIndex].downStart)/60);

							console.log("Main Block offset: " + offset);
							console.log("Downtime Block offset: " + downtimeOffset);
							console.log("Downtime Block Size: " + downtimeBlockSize);
							console.log("Downtime Block Duration: " + downtimeDuration);
							console.log("Downtime Block Width: " + ((downtimeBlockSize * cellWidth)) + "px");
							console.log("===================");

							var downtimeblock = jQuery("<div>", {
								"class": "ganttview-downtimeblock",
								"title": "Downtime: " + downtimeDuration + "Minutes",
								"css": {
									"width": ((downtimeBlockSize * cellWidth)) + "px",
									"margin-left": ((downtimeOffset * cellWidth)) + "px"
								}
							});
							jQuery(rows[rowIdx]).append(downtimeblock);
						}
					}
				}
				jQuery(rows[rowIdx]).append(block);
				rowIdx = rowIdx + 1;
			}
		}			
	}

	function addBlockData(block, data, workSequenceID, dataSeriesID, blockNumber, dataSeriesLength, series, blockCSSOffset) {
		// This allows custom attributes to be added to the series data objects
		// and makes them available to the 'data' argument of click, resize, and drag handlers
		var blockData = { work_id: data.id, workName: data.name, workSequenceID: workSequenceID, dataSeriesID: dataSeriesID, blockNumber: blockNumber, dataSeriesLength: dataSeriesLength, blockCSSOffset: blockCSSOffset};
		jQuery.extend(blockData, series);
		block.data("block-data", blockData);
		blockStore.push(block);
	}

	function applyLastClass(div) {
		jQuery("div.ganttview-grid-row div.ganttview-grid-row-cell:last-child", div).addClass("last");
		jQuery("div.ganttview-hzheader-days div.ganttview-hzheader-day:last-child", div).addClass("last");
		jQuery("div.ganttview-hzheader-months div.ganttview-hzheader-month:last-child", div).addClass("last");
	}

	return {
		render: render
	};
}

var Behavior = function (div, opts) {

	function apply() {

		if (opts.behavior.clickable) {
			bindBlockClick(div, opts.behavior.onClick); 
		}

		if (opts.behavior.resizable) {
			bindBlockResize(div, opts.cellWidth, opts.start, opts.behavior.onResize); 
		}

		if (opts.behavior.draggable) {
			bindBlockDrag(div, opts.cellWidth, opts.start, opts.behavior.onDrag); 
		}
	}

	function bindBlockClick(div, callback) {
		jQuery("div.ganttview-block", div).on("click", function () {
			if (callback) { callback(jQuery(this).data("block-data")); }
		});
		$(".navbar-confirm-button").on("click", function () {
			var blockDataStore = [];

			var blockStoreLength = blockStore.length;
			for(var blockStoreIndex = 0; blockStoreIndex < blockStoreLength; blockStoreIndex++)
			{
				var blockStoreSeriesLength = blockStore[blockStoreIndex].data("block-data").dataSeriesLength;
				//console.log("Test" /*blockStoreIndex + ": " + $( this ).text()*/);
				var blockSeriesWholeData = [];
				var currentBlockSeriesData = [];

				for(var dataSeriesIndex = 0; dataSeriesIndex < blockStoreSeriesLength; dataSeriesIndex++)
				{
					$.each(blockStore[blockStoreIndex + dataSeriesIndex].data("block-data").downtime, function (key, obj)
					{
						obj.downStart = convertISODateToGanttFormat(new Date(obj.downStart));
						obj.downEnd = convertISODateToGanttFormat(new Date(obj.downEnd));
					});
					currentBlockSeriesData.push({
						id: blockStore[blockStoreIndex + dataSeriesIndex].data("block-data").id,
						name: blockStore[blockStoreIndex + dataSeriesIndex].data("block-data").name,
						start: convertISODateToGanttFormat(new Date(blockStore[blockStoreIndex + dataSeriesIndex].data("block-data").start)),
						end: convertISODateToGanttFormat(new Date(blockStore[blockStoreIndex + dataSeriesIndex].data("block-data").end)),
						color: blockStore[blockStoreIndex + dataSeriesIndex].data("block-data").color,
						downtime: blockStore[blockStoreIndex + dataSeriesIndex].data("block-data").downtime
					});
				}
				blockDataStore.push({
					id: blockStore[blockStoreIndex].data("block-data").work_id,
					name: blockStore[blockStoreIndex].data("block-data").workName,
					series: currentBlockSeriesData
				});
				blockStoreIndex += (blockStoreSeriesLength-1);
				//console.log(JSON.stringify(blockStore[blockStoreIndex].data("block-data")));
				//blockDataStore.push(blockStore[blockStoreIndex].data("block-`		data"));
			}
			// $(blockStore).each(function( blockStoreIndex ) {
				
				// });
				//console.log(JSON.stringify(blockDataStore));
				var canvas = document.getElementById("ganttview-arrow-canvas");
				canvas.width = 39312;
				canvas.height = 1536;
				var ctx = canvas.getContext("2d");
				//drawArrow(ctx, 100, 48, 120, 61, 1.7);
				var ganttData = JSON.stringify(blockDataStore);
				ganttData = ganttData.replace(/"[n][e][w]\s[D][a][t][e]\S[^\n]/g, 'new Date(').replace(/[^\n]"[)]"/g, '")');
				var modifiedJSON = "var workHours = " + JSON.stringify(workHours) + ";" + "\nvar headerData = " + JSON.stringify(headerData) + ";"  + "\nvar ganttData = " + ganttData + ";"
				console.log(modifiedJSON);

				$.ajax({
					type: "POST",
					url: "https://tstdrv1936563.app.netsuite.com/app/site/hosting/restlet.nl?script=561&deploy=1",
					data: modifiedJSON,
					async: true,
					contentType: "text/plain",
					dataType: "text",
					success: function(resultData) { 
						alert(resultData);
					}
				});
			});
	}

	function bindBlockResize(div, cellWidth, startDate, callback) {
		jQuery("div.ganttview-block", div).resizable({
			grid: cellWidth,
			handles: "e",
			stop: function () {
				var block = jQuery(this);
				updateDataAndPosition(div, block, cellWidth, startDate);
				if (callback) { callback(block.data("block-data")); }
			}
		});
	}

	function bindBlockDrag(div, cellWidth, startDate, callback) {
		console.log("Offset: " + ($("div.ganttview-block", div).data("block-data").blockCSSOffset));
		console.log("containment value: " + (0-($("div.ganttview-block", div).data("block-data").blockCSSOffset) * cellWidth));
		jQuery("div.ganttview-block", div).draggable({
			axis: "x", 
			grid: [cellWidth, cellWidth],
			containment: "parent.parent",
			scrollSensitivity: 100,
			scrollSpeed: 15,
			stop: function () {
				var block = jQuery(this);
				$("#indexStore").html(block.data("block-data").blockNumber);				
				updateDataAndPosition(div, block, cellWidth, startDate);
				if (callback) { callback(block.data("block-data")); }
			}
		});
	}

	function drawArrow(ctx, x1, y1, x2, y2, width) {

		distance = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
		console.log(distance);
		radius = (Math.sqrt(distance)/50);
		ctx.fillStyle = "#21739c";
		ctx.lineWidth = width;
		ctx.strokeStyle = "#21739c";
		ctx.beginPath();
		ctx.moveTo(x1, y1);
		ctx.lineTo(x2 - radius, y1);
		ctx.arcTo(x2, y1, x2, (((y2 - y1) * 0.8) + y1), radius);
		ctx.lineTo(x2, y2);
		ctx.stroke();

		$('.point').css('border-top', "4px solid transparent");
		$('.point').css('border-bottom', "4px solid transparent");
		$('.point').css('border-left', "14px solid #21739c");
		$('.point').css('margin-top', (y2*2)-2 + "px");
		$('.point').css('margin-left', (x2 - 7) + "px");
	}

	function moveWeldingBlockWO48()
	{
		blockStore[6].css("top", "").css("left", "")
			.css("position", "relative").css("margin-left", 108 + "px");
	}

	function updateDataAndPosition(div, block, cellWidth, startDate) {
		var container = jQuery("div.ganttview-slide-container", div);
		var scroll = container.scrollLeft();
		var offset = block.offset().left - container.offset().left - 1 + scroll;

		//Fetching and calculating block data before it was dragged/resized
		oldStart = block.data("block-data").start;
		oldEnd = block.data("block-data").end;

		var oldWeekendCount = countWeekendDays(oldStart, oldEnd);

		if(oldWeekendCount%2 == 1)oldWeekendCount++; //Weekend Calculation Adjustment

		// Set new start date
		var daysFromStart = Math.round(offset / cellWidth);
		var newStart = startDate.clone().addDays((daysFromStart/numberOfHours));
		newStart = newStart.addHours((daysFromStart%numberOfHours));

		// Setting Minutes of new start from previous data
		var oldStartMinutes = oldStart.clone();
		var startMinutes = oldStartMinutes.getMinutes();
		newStart.setMinutes(startMinutes);

		/*------------IF THE USER PLACED THE BLOCK STARTING ON/WITHIN A WEEKEND------------*/

		if (DateUtils.isWeekend(newStart))
		{
			if(newStart.getDay()/6 == 1)
			{
				// Adding two days if start is on Saturday
				newStart = newStart.clone().addDays(2);
			}
			else
			{
				// Adding one day if start is on Sunday
				newStart = newStart.clone().addDays(1);
			}

			// Calculating duration from block to keep parity
			var oldDuration = DateUtils.workDurationExcludingWeekends(oldStart, oldEnd);

			// Setting hour as first hour of the day as default
			newStart.setHours(hours[0]);

			// Calculating offset
			var newDaysFromStart = Math.floor(DateUtils.workDurationIncludingWeekends(startDate, newStart)/60);

			var newEnd = newStart.clone();

			// Calculating hours of work to be done
			var workDurationHours = (oldDuration/60);

			// Calculating number of weeks of work to be done from no.of hours
			var numberOfWeeks = (Math.floor(workDurationHours/(numberOfHours*5)));

			// Adding 7 days of time in block for every 5 business days of work
			newEnd = newEnd.addDays((numberOfWeeks*7));

			// Finding out remaining hours after weeks have been added
			var numberOfRemainingHours = (workDurationHours % (numberOfHours*5));

			// Adding the remaining hours in the form of days after weeks have been added
			newEnd = newEnd.addDays(Math.floor(numberOfRemainingHours/numberOfHours));

			// Calculating the remaining hours after days have been added and then adding to newEnd
			newEnd.addHours(numberOfRemainingHours % numberOfHours);

			// Setting Minutes of new end from previous data
			var oldEndMinutes = oldEnd.clone();
			var EndMinutes = oldEndMinutes.getMinutes();
			newEnd.setMinutes(EndMinutes);

			// Adjusting date and time if it's beyond 17:00
			if((newEnd.getHours() == ((hours[numberOfHours-1])+1)) && (newEnd.getMinutes()!=0))
			{
				newEnd.setHours(hours[0]);
				newEnd.addDays(1);
			}

			// Calculating weekends between new start and new end
			var weekendCount = 0;
			weekendCount = countWeekendDays(newStart, newEnd);
			if(weekendCount%2 == 1)weekendCount++;
			if(weekendCount > (numberOfWeeks*2))
			{
				// If we find out that weekend count is more than the number of weeks added manually, then we increment number of days by 2 [Wil happen when you say.. add 4 days to Thursday, result will be Wednesday, so there should be 2 days of weekend]
				newEnd = newEnd.addDays((weekendCount-(numberOfWeeks*2)));
			}

			// If we find that the block is ending within a weekend, then we increment number of days by 2
			if (DateUtils.isWeekend(newEnd))
			{
				newEnd = newEnd.addDays(2);
				weekendCount += 2;
			}

			// Creating a copy of new start and setting minutes to 0 to get the proper width of block
			startTimeCopy = newStart.clone();
			startTimeCopy.setMinutes(00);
			var newSize = Math.ceil(DateUtils.workDurationExcludingWeekends(startTimeCopy, newEnd)/60);

			// Adding weekends to newSize (which is calculated without weekends)
			newSize += (numberOfHours*weekendCount);

			// Setting new block data
			block.data("block-data").start = newStart;
			block.data("block-data").end = newEnd;

			// Calculating CSS Properties : Offset and Width of block
			newSize = ((newSize*cellWidth) - 9);
			offset = ((newDaysFromStart * cellWidth) + 3);

			// Setting CSS Properties : Offset and Width of block
			block.css("top", "").css("left", "")
			.css("position", "relative").css("margin-left", offset + "px").css("width", newSize + "px");
		}

		/*------------------------------------NORMAL SCENARIO------------------------------------*/

		else
		{
			block.data("block-data").start = newStart;

			// Set new end date
			var width = block.outerWidth();
			var numberOfDays = Math.round(width / cellWidth) - 1; //Width is always cellWidth+1px, OuterWidth is always cellWidth+2px

			// Finding end date from block css
			numberOfDays += daysFromStart - (oldWeekendCount*numberOfHours);
			var newEnd = startDate.clone().addDays((numberOfDays/numberOfHours));
			newEnd = newEnd.addHours((numberOfDays%numberOfHours));

			var newWeekendCount = countWeekendDays(newStart, newEnd);
			if(newWeekendCount%2 == 1)newWeekendCount++;
			newEnd = newEnd.addDays(newWeekendCount);

			// Setting Minutes of new end from previous data
			var oldEndMinutes = oldEnd.clone();
			var EndMinutes = oldEndMinutes.getMinutes();
			if(EndMinutes !=0)
			{
				newEnd.setMinutes(EndMinutes);
			}
			// Adjusting time by 1 hr extension if minutes is 0 (Since we are calculating End Date from CSS and not Duration)
			else
			{
				newEnd = newEnd.addHours(1);
			}

			// Setting new end date
			block.data("block-data").end = newEnd;
			//jQuery("div.ganttview-block-text", block).text(numberOfDays + 1);

			var newWidth = width + ((newWeekendCount - oldWeekendCount)*cellWidth*numberOfHours)-2;

			// Remove top and left properties to avoid incorrect block positioning,
			// Set position to relative to keep blocks relative to scrollbar when scrolling
			block.css("top", "").css("left", "")
			.css("position", "relative").css("margin-left", offset + "px").css("width", newWidth + "px");

		}


		/*---------------------------------DEBUGGER STUFF---------------------------------*/

		/*console.log("Work Name: "+block.data("block-data").workName);
		console.log("Block Name: "+block.data("block-data").name);
		console.log("Work Sequence ID:"+block.data("block-data").workSequenceID);
		console.log("Series ID: "+block.data("block-data").dataSeriesID);
		console.log("Block Number: "+block.data("block-data").blockNumber);
		console.log("Series Length: "+block.data("block-data").dataSeriesLength);
		console.log("NewWidth :"+newWidth);
		console.log("OldWeekendCount :"+oldWeekendCount);
		console.log("NewWeekendCount :"+newWeekendCount);
		console.log("Original Block Old Start Time: "+oldStart);
		console.log("Original Block Old Stop Time: "+oldEnd);
		console.log("Original Block New Start Time: "+block.data("block-data").start);    
		console.log("Original Block New Stop Time: "+block.data("block-data").end);*/

		/*---------------------------------DEBUGGER STUFF---------------------------------*/

		// Calling auto update function to adjust position of other blocks
		if(((block.data("block-data").blockNumber)+1) != blockStore.length)
		{
			autoUpdateBlocks(div, blockStore[((block.data("block-data").blockNumber)+1)], cellWidth, startDate);
		}
	}

	function autoUpdateBlocks(div, block, cellWidth, startDate) {

		// Collecting block data which would be needed later
		var blockNumber = block.data("block-data").blockNumber;
		var blockName = block.data("block-data").name;
		var blockColor = block.data("block-data").color;
		var seriesLength = block.data("block-data").dataSeriesLength;

		var len = blockStore.length;

		// Two different variables assigned with default block start time. One will be used for series comparison and other for work center
		var previousSeriesBlockEndTime = block.data("block-data").start.clone();
		var previousIdenticalBlockEndTime = block.data("block-data").start.clone();
		var newStart = block.data("block-data").start.clone();

		// Calculating offset from Block CSS
		var container = jQuery("div.ganttview-slide-container", div);
		var scroll = container.scrollLeft();
		var offset = block.offset().left - container.offset().left - 1 + scroll;

		// Fetching and calculating block data before it was dragged/resized
		var oldStart = block.data("block-data").start.clone();
		var oldEnd = block.data("block-data").end.clone();
		var oldDuration = DateUtils.workDurationExcludingWeekends(oldStart, oldEnd);

		// Old Weekend Count Calculation & Adjustment
		var oldWeekendCount = countWeekendDays(oldStart, oldEnd);
		if(oldWeekendCount%2 == 1)oldWeekendCount++;

		// Calculating series ID of next block in the series if there's any
		var seriesID = (block.data("block-data").dataSeriesID);

		// Checking if there's any further blocks in the series
		if(seriesID > 1)
		{
			var previousSeriesBlockEndTime = blockStore[blockNumber-1].data("block-data").end.clone();
		}

		// Finding end time of last block from the same Work Center
		for(var index = (blockNumber-1); index >=0; --index)
		{
			var loopBlock = blockStore[index];
			if(loopBlock.data("block-data").color == blockColor)
			{
				previousIdenticalBlockEndTime = loopBlock.data("block-data").end.clone();
				break;
			}
		}

		// Assigning block start time as whichever related block ended later (Series Block or Work Center Block)
		if(previousSeriesBlockEndTime <= previousIdenticalBlockEndTime)
		{
			newStart = previousIdenticalBlockEndTime.clone();
		}
		else
		{
			newStart = previousSeriesBlockEndTime.clone();
		}

		// Checking if the greater of the two block start times is actually greater than the start time of the block which we are editing here
		if(oldStart > newStart)
		{
			newStart = oldStart.clone();
		}

		// Setting new block start time
		block.data("block-data").start = newStart.clone();

		// Setting newEnd if the block requires to be moved
		if(newStart != oldStart)
		{
			// Calculating offset of new block
			var newOffset = Math.floor(DateUtils.workDurationIncludingWeekends(startDate, block.data("block-data").start)/60);

			// Setting default end time
			var newEnd = newStart.clone();

			// Calculating hours of work to be done
			var workDurationHours = (Math.floor(oldDuration/60));

			// Calculating number of weeks of work to be done from no.of hours
			var numberOfWeeks = (Math.floor(workDurationHours/(numberOfHours*5)));

			// Adding 7 days of time in block for every 5 business days of work
			newEnd = newEnd.addDays((numberOfWeeks*7));

			// Finding out remaining hours after weeks have been added
			var hourCount = ((newStart.getHours()) - (hours[0]));
			var remainderHours = (workDurationHours % (numberOfHours*5));
			var totalHours = hourCount + remainderHours;

			// Adding the remaining hours in the form of days after weeks have been added
			newEnd = newEnd.addDays(Math.floor(totalHours/numberOfHours));

			// Calculating the remaining hours after days have been added
			totalHours = (totalHours % numberOfHours);

			// Setting remainining hours as nth business hour of the day
			newEnd.setHours(hours[(totalHours)]);

			// Setting Minutes of new end. Extracting new start minutes and remaining minutes, adding them up
			var minutes = newStart.getMinutes();
			minutes += (oldDuration%60);

			// Checking if added minutes is greater than 60, if so - adding an hour to the count and then setting minutes
			if(minutes>59)
			{
				newEnd = newEnd.addHours(1);
				minutes -= 60;
			}
			newEnd.setMinutes(minutes);

			// Checking if the time is beyond 17:00 after adding an hour to the time, if so - adjusting the date by adding another day
			if((newEnd.getHours() > ((hours[numberOfHours-1]))) && (newEnd.getMinutes()!=0))
			{
				newEnd.setHours(hours[((newEnd.getHours())-(hours[numberOfHours-1])-1)]);
				newEnd.addDays(1);
			}

			// Calculating weekends between new start and new end
			var newWeekendCount = 0;
			newWeekendCount = countWeekendDays(newStart, newEnd);
			if(newWeekendCount%2 == 1)newWeekendCount++;
			if(newWeekendCount > (numberOfWeeks*2))
			{
				// If we find out that weekend count is more than the number of weeks added manually, then we increment number of days by 2
				newEnd = newEnd.addDays((newWeekendCount-(numberOfWeeks*2)));
			}

			// If we find that the block is ending within a weekend, then we increment number of days by 2
			if (DateUtils.isWeekend(newEnd))
			{
				newEnd = newEnd.addDays(2);
				newWeekendCount += 2;
			}

			// Creating a copy of new start and setting minutes to 0 to get the proper width of block
			var startTime = newStart.clone();
			startTime.setMinutes(00);
			var newSize = Math.ceil(DateUtils.workDurationExcludingWeekends(startTime, newEnd)/60);

			// Adding weekends to newSize (which is calculated without weekends)
			newSize += (numberOfHours*newWeekendCount);

			// Calculating CSS Properties : Width of block
			var newWidth = ((newSize * cellWidth) - 9);

			// Assigning block end time
			block.data("block-data").end = newEnd;

			// Setting CSS Properties : Offset and Width of block
			block.css("top", "").css("left", "")
			.css("position", "relative").css("margin-left", ((newOffset * cellWidth) + 3) + "px").css("width", newWidth + "px");
		}

		// Calling function again to calculate position of the block below the current block
		if((blockNumber+1) != len)
		{
			autoUpdateBlocks(div, blockStore[blockNumber+1], cellWidth, startDate);
		}
	}
	return {
		apply: apply
	};
}

var ArrayUtils = {

	contains: function (arr, obj) {
		var has = false;
		for (var i = 0; i < arr.length; i++) { if (arr[i] == obj) { has = true; } }
			return has;
	}
};

var DateUtils = {

	// workDurationIncludingWeekends Calculates minutes between two dates including weekends
	workDurationIncludingWeekends: function (start, end) {
		if (!start || !end) { return 0; }
		start = Date.parse(start); end = Date.parse(end);
		if (start.getYear() == 1901 || end.getYear() == 8099) { return 0; }
		var count = 0, date = start.clone();
		var range = getRange(start,end);
		return range;
	},

	// workDurationExcludingWeekends Calculates minutes between two dates excluding weekends, calculates the actual duration of block
	workDurationExcludingWeekends: function (start, end) {
		if (!start || !end) { return 0; }
		start = Date.parse(start); end = Date.parse(end);
		if (start.getYear() == 1901 || end.getYear() == 8099) { return 0; }
		var count = 0, date = start.clone();
		var duration = getDuration(start,end);
		return duration;
	},

	isWeekend: function (date) {
		return date.getDay() % 6 == 0;
	},

	getBoundaryDatesFromData: function (data, minDays) {
		var minStart = new Date(); maxEnd = new Date();
		for (var i = 0; i < data.length; i++) {
			for (var j = 0; j < data[i].series.length; j++) {
				var start = Date.parse(data[i].series[j].start).clone();
				var end = Date.parse(data[i].series[j].end).clone();
				if (i == 0 && j == 0) { minStart = start; maxEnd = end; }
				if (minStart.compareTo(start) == 1) { minStart = start; }
				if (maxEnd.compareTo(end) == -1) { maxEnd = end; }
			}
		}

		// Ensure that the width of the chart is at least the slide width to avoid empty
		// whitespace to the right of the grid
		if (Math.floor(DateUtils.workDurationIncludingWeekends(minStart, maxEnd)/60) < minDays) {
			maxEnd = minStart.clone().addDays(minDays);
		}

		minStart.setHours(hours[0]);
		minStart.setMinutes(00);
		return [minStart, maxEnd];
	}
};
function diff_minutes(dt2, dt1)
{

	var diff =(dt1.getTime() - dt2.getTime()) / 1000;
	diff /= 60;
	return Math.round(diff);

}

function formatTime(getDatetime) {

	var currentDate = new Date(getDatetime);
	var currentHours = currentDate.getHours();
	var minutes = currentDate.getMinutes();
	var sec = currentDate.getSeconds();
	var ampm = currentHours >= 12 ? 'pm' : 'am';
	currentHours = currentHours % 12;
	currentHours = currentHours ? currentHours : 12;
	minutes = minutes < 10 ? '0' + minutes : minutes;
	var formatedTime = currentHours + ':' + minutes + ' ' + ampm;
	return formatedTime;
}

function formatDate(date) {

	var d = new Date(date),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();

	if (month.length < 2)
		month = '0' + month;
	if (day.length < 2)
		day = '0' + day;

	return [month, day, year].join('/');
}

function getRange(start, end)
{
	var StartTimes=["8:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","8:00:00 AM"];
	var EndTimes=["5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM"];
	var start = new Date(start);
	var end = new Date(end);

	var totalMinutes = 0;
	for (var currentDate = new Date(formatDate(start)); currentDate <= new Date(formatDate(end)); currentDate.setDate(currentDate.getDate() + 1)) 
	{
		var startDate = start;
		var endDate = end;
		var startFormatedDay = formatDate(startDate);
		var loopDay = formatDate(currentDate);
		var endDay = formatDate(end);

		if(startFormatedDay == loopDay)
		{
			if(loopDay == endDay)
			{
				endDate.setMinutes(00);
				var currentEnd = endDate;
			}
			else
			{
				var dayIndex = new Date(loopDay);
				var dayIndex = dayIndex.getDay();
				var currentEnd = loopDay+" "+EndTimes[dayIndex];
			}
			startDate.setMinutes(00);
			var main_difference = diff_minutes(new Date(startDate), new Date(currentEnd));
			var difference = Math.round(main_difference/60) + 1;
			remiander = main_difference%60;
			totalMinutes += main_difference;
		}
		else if(loopDay == endDay)
		{ 
			var dayIndex = new Date(endDay);
			var dayIndex = dayIndex.getDay();
			var endDay = endDay +" "+  StartTimes[dayIndex];
			endDate.setMinutes(00);
			var main_difference = diff_minutes(new Date(endDay), new Date(endDate));
			var difference = Math.round(main_difference/60) + 1;
			remiander = main_difference%60;
			totalMinutes += main_difference;
		} 
		else
		{
			var difference = 10;
			totalMinutes += main_difference;
		}
	}
	return totalMinutes;
}

function getDuration(start, end) {

	var StartTimes=["8:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","08:00:00 AM","8:00:00 AM"];
	var EndTimes=["5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM","5:00:00 PM"];
	var start = new Date(start);
	var end = new Date(end);
	var totalMinutes = 0;
	for (var currentDate = new Date(formatDate(start)); currentDate <= new Date(formatDate(end)); currentDate.setDate(currentDate.getDate() + 1)) 
	{
		var startDate = start;
		var endDate = end;
		var startFormatedDay = formatDate(startDate);
		var loopDay = formatDate(currentDate);
		var endDay = formatDate(end);
		var checkWeekend = new Date(loopDay);
		var weekEnd =  checkWeekend.getDay();
		if(startFormatedDay == loopDay)
		{
			if(parseInt(weekEnd) != 6)
			{
				if(parseInt(weekEnd) != 0)
				{
					if(loopDay == endDay)
					{
						var currentEnd = endDate;
					}
					else
					{
						var dayIndex = new Date(loopDay);
						var dayIndex = dayIndex.getDay();
						var currentEnd = loopDay+" "+EndTimes[dayIndex];
					}
					var difference = diff_minutes(new Date(startDate), new Date(currentEnd));
					totalMinutes += difference;
				}
			}
		}
		else if(loopDay == endDay)
		{
			var dayIndex = new Date(endDay);
			var dayIndex = dayIndex.getDay();
			var endDay = endDay +" "+  StartTimes[dayIndex];
			var difference = diff_minutes(new Date(endDay), new Date(endDate));
			totalMinutes += difference;
		}
		else
		{
			if(parseInt(weekEnd) != 6)
			{
				if(parseInt(weekEnd) != 0)
				{
					var dayIndex = new Date(loopDay);
					var dayIndex = dayIndex.getDay();
					var CurrStartDateTime = loopDay+" "+StartTimes[dayIndex];
					var CurrEndDateTime = loopDay+" "+EndTimes[dayIndex];
					var difference = diff_minutes(new Date(CurrStartDateTime), new Date(CurrEndDateTime));
					totalMinutes += difference;
				}
			}
		}
	}
	return totalMinutes;
}
function countWeekendDays( d0, d1 ) {

	var ndays = 1 + Math.round((d1.getTime()-d0.getTime())/(24*3600*1000));
	var nsundays = Math.floor((ndays + (d0.getDay() + 6) % 7) / 7);
	return 2*nsundays + (d1.getDay()==6) - (d0.getDay()==0);
}
function convertISODateToGanttFormat(givenDate)
{
	var month = givenDate.getMonth() + 1; //months from 1-12
	var day = givenDate.getDate();
	var year = givenDate.getFullYear();
	var hours = givenDate.getHours();
	var mins = givenDate.getMinutes();
	var ampm = hours >= 12 ? 'PM' : 'AM';
	if(ampm == 'PM')
		hours -= 12;
	if(hours < 10)
		hours = '0' + hours;
	if(mins < 10)
		mins = '0' + mins;
	var resultDate = 'new Date("' + month + "/" + day + "/" + year + ' ' + hours + ':' + mins + ' ' + ampm + '")';
	return resultDate;
}
})(jQuery);

/*
Weekends should not affect downtime duration calculation


Possible solution:

Adjust OldEnd right at the start, deducting the currentdowntime
// store original OldEnd OR store difference between new Oldend and newly calculated OldEnd

//Deduct 7 days from block for 45 hours of downtime (Given work done per week is : 45hrs)

oldEnd = OldEnd-{Downtime/(WorkHours Per day * Number of WorkDays in week)}*7

//Deduct 1 day for 9 hrs a day 
//Deduct remaining hours and check if it goes past 8am like if it's 7am, go back to previous day)
//Deduct remaining minutes and check if it goes past 8am like if it's 7:30am, go back to previous day
//Check if the "new" oldEnd lies on a weekend, if so, add 2 days 


=========

For if part
Duration is already calculated, after all the calculation is done, check if any downtime start lies between newStart and newEnd - if so, add the duration to newEnd for each downtime detected [add Minutes as well] [Performance might be affected]

// Have to think :
If we skip a downtime start which intitially occurs after newEnd, but after we add other downtimes, it may go past the skipped downtime start, so we should add that downtime too [Solution : Sort the downtime array]

For else part

Deduct oldEnd and newly calculated OldEnd difference from width : width = {width- (cellWidth * difference)}
calculate numberOfdays(Number of cells) from calculated width

After all the calculation is done, check if any downtime start lies between newStart  and newEnd - if so, add it to newEnd using the calculation method used in if part for calculating newEnd (not Downtime) for each downtime detected [add Minutes as well] [Performance might be affected]

****THINGS TO ASK*****

Minutes are set without any calculation, what to do when downtime duration is less than 60 minutes 

MyView
Just add minutes and calculate
*/