/**
 *@NApiVersion 2.1
 *@NScriptType Suitelet
 */
define(["N/task","N/log","N/https","N/runtime"], function(task,log,https,runtime) {
    function onRequest(context) {
      var schedulerData = context.request.parameters.input;
      
      
      log.debug({
          title: 'PCT-FS',
          details:'Data:'+JSON.stringify(schedulerData)
      });
      callSchedule() ;
    }
  
    /*function executeScheduled() {
      var scriptTask = task.create({
        taskType: task.TaskType.MAP_REDUCE,
        scriptId: "customscript_sdr_ss_product_shortage",
        deploymentId: "customdeployprodshortsearch"
      });
  
      var scriptTaskId = scriptTask.submit();
  
      log.debug("scriptTaskId", scriptTaskId);
  
    }*/
    function callSchedule() {
      log.debug({
          title: 'PCT-FS',
          details: 'Calling schedule'
      })
    }
  
    return {
      onRequest: onRequest
    };
  });
  