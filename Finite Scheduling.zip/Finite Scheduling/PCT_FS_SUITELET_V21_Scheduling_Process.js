/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
define(['N/ui/serverWidget', 'N/record', 'N/runtime', 'N/file', 'N/log', 'N/search', 'N/plugin'],

    function (serverWidget, record, runtime, file, log, search, plugin)
    {
        /**
         * Definition of the Suitelet script trigger point.
         *
         * @param {Object} context
         * @param {ServerRequest} context.request - Encapsulation of the incoming request
         * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
         * @Since 2015.2
         */
        function onRequest(context)
        {
            var currentUser = runtime.getCurrentUser();
            // var userLocation = currentUser.location;
            // var userSubsidiary = currentUser.subsidiary;
            var userId = currentUser.id;
            var fieldLookUp = search.lookupFields({
                type: search.Type.EMPLOYEE,
                id: userId,
                columns: ['location', 'subsidiary']
            });
            /*log.debug({
                title: 'PCT-FS',
                details: 'Lookup Value:' + JSON.stringify(fieldLookUp)
            });*/
            if (typeof (fieldLookUp.location[0]) === "undefined")
            {
                userLocation = '';
            }
            else
            {
                var userLocation = fieldLookUp.location[0].text;
            }
            if (typeof (fieldLookUp.subsidiary[0]) === "undefined")
            {
                userSubsidiary = '';
            }
            else
            {
                var userSubsidiary = fieldLookUp.subsidiary[0].text;
            }
           
            var Form = serverWidget.createForm({
                title: "Schedule Tasks",
            });
            var htmlField = Form.addField({
                id: 'custpage_template',
                type: serverWidget.FieldType.INLINEHTML,
                label: 'HTML Image'
            });
            var fileObj = file.load({
                id: './PCT_FS_index.html'
            });

            var template = fileObj.getContents();
           
            htmlField.defaultValue = template;
            var clientFileId = 0;
            var clientFileIdSearch = search.create({
                type: "folder",
                filters:
                    [
                        ["file.name", "haskeywords", "PCT_FS_CS_V21_PI_Button_Call_Function"]
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "internalid",
                            join: "file",
                            label: "File Id"
                        })
                    ]
            });
            var clientFileIdSearchCount = clientFileIdSearch.runPaged().count;
            //log.debug("PCT-FS", 'Count:' + clientFileIdSearchCount);
            var clientFileIdSearchResult = clientFileIdSearch.run().getRange({
                start: 0,
                end: clientFileIdSearchCount
            });
            if (clientFileIdSearchCount > 0)
            {
                for (var clientFileIdIndex = 0; clientFileIdIndex < clientFileIdSearchCount; clientFileIdIndex++)
                {
                    clientFileId = clientFileIdSearchResult[clientFileIdIndex].getValue({ name: "internalid", join: "file" });
                    
                }
            }
            //Recived Parameters

            var postItemId = context.request.parameters.custpage_itemField;
            var postQty = context.request.parameters.custpage_qty;
            var postMoveFirst = context.request.parameters.custpage_chkmovefirst;
            var postDate = context.request.parameters.custpage_date;
            var postStartTime = context.request.parameters.custpage_startTime;
            var postEndTime = context.request.parameters.custpage_endTime;
            var blnAddFirst = (postMoveFirst == 'T');

           /* log.debug({
                title: 'PCT-FS',
                details: 'Post Data:(Item:' + postItemId + ',Quantity:' + postQty + ',Move First:' + postMoveFirst + ',Date:' + postDate + ',Start Time:' + postStartTime + ',End Time:' + postEndTime + ')'
            });*/

            var newTasksCount = 0;
            if (postItemId != null && postQty != null && postItemId != "" && postQty != "")
            {
                // var ietmFieldObject = {
                //     fieldId: 'custpage_itemField',
                //     value: postItemId
                // };
                // var QuantityObject = {
                //     fieldId: 'custpage_qty',
                //     value: postQty
                // };
                // var chkMoveFirstObject = {
                //     fieldId: 'custpage_chkmovefirst',
                //     value: postMoveFirst
                // };
                // var timeObject = {
                //     fieldId: 'custpage_time',
                //     value: postTime
                // };
                // var startTimeObject = {
                //     fieldId: 'custpage_startTime',
                //     value: postStartTime
                // };
                // var endTimeObject = {
                //     fieldId: 'custpage_endTime',
                //     value: postEndTime
                // };
                // Form.setValue(ietmFieldObject);
                // Form.setValue(QuantityObject);
                // Form.setValue(chkMoveFirstObject);
                // Form.setValue(timeObject);
                // Form.setValue(startTimeObject);
                // Form.setValue(endTimeObject);
                var bomFilters = new Array();
                bomFilters.push(search.createFilter({ name: 'assembly', join: 'assemblyitem', operator: search.Operator.ANYOF, values: postItemId, }));
                bomFilters.push(search.createFilter({ name: 'default', join: 'assemblyitem', operator: search.Operator.IS, values: 'T', }));

                var bomSearch = search.create({
                    type: search.Type.BOM,
                    filters: bomFilters
                });
                var dataRouting = new Array();
                var bomSearchCount = bomSearch.runPaged().count;
                var bomSearchResult = bomSearch.run().getRange({
                    start: 0,
                    end: bomSearchCount
                });
                if (bomSearchCount > 0)
                {
                    for (var bomIndex = 0; bomIndex < bomSearchCount; bomIndex++)
                    {
                        var bomId = bomSearchResult[bomIndex].id;
                        /*log.debug({
                            title: 'PCT-FS',
                            details: 'Bom Id:' + bomId
                        });*/
                    }
                    var mfgRoutingSearch = [];
                    mfgRoutingSearch = search.create({
                        type: "manufacturingrouting",
                        filters: [
                            ["isdefault", "is", "T"]
                        ],
                        columns: [
                            search.createColumn({ name: "isdefault", label: "Default" }),
                            search.createColumn({
                                name: "name",
                                sort: search.Sort.ASC,
                                label: "Name"
                            }),
                            search.createColumn({ name: "operationname", label: "Operation Name" }),
                            search.createColumn({ name: "manufacturingworkcenter", label: "Manufacturing Work Center" }),
                            search.createColumn({
                                name: "formulanumeric",
                                formula: "{manufacturingworkcenter.id}",
                                label: "WCID"
                            }),
                            search.createColumn({
                                name: "sequence",
                                sort: search.Sort.ASC,
                                label: "Operation Sequence"
                            }),
                            search.createColumn({ name: "runrate", label: "Run Rate" }),
                            search.createColumn({ name: "billofmaterials", label: "Bill of Materials" })
                        ]
                    });
                    mfgRoutingSearch.filters.push(search.createFilter({ name: 'billOfMaterials', operator: search.Operator.ANYOF, values: bomId }));

                } else
                {
                    mfgRoutingSearch = null; //no routing found
                }
                if (mfgRoutingSearch != null)
                {
                    var intJobId = 1;
                    var intTaskid = 1;
                    var newTasks = new Array();
                    var mfgRoutingSearchCount = mfgRoutingSearch.runPaged().count;
                   /* log.debug({
                        title: 'PCT-LOG',
                        details: 'Manufacturing Routing Search Count = ' + mfgRoutingSearchCount
                    })*/
                    var mfgRoutingSearchResult = mfgRoutingSearch.run().getRange({
                        start: 0,
                        end: mfgRoutingSearchCount
                    });

                    if (parseInt(mfgRoutingSearchCount) > 0)
                    {
                        for (var mfgRoutingIndex = 0; mfgRoutingIndex < mfgRoutingSearchCount; mfgRoutingIndex++)
                        {
                            // var routingId = mfgRoutingSearchResult[mfgRoutingIndex].getValue({
                            //     name: 'workorder'
                            // });
                            // log.debug({
                            //     title: 'PCT-FS',
                            //     details: 'Routing Id:' + routingId
                            // });
                            var pIntId;
                            if (i == 0)
                            {
                                pIntId = -1; //gets the first one to be -1
                            } else
                            {
                                pIntId = intTaskid - 1;
                            }
                            var newTask = new Object;
                            newTask['JInternalId'] = intJobId;
                            newTask['InternalId'] = intTaskid;
                           /* log.debug({
                                title: 'PCT-FS-manufacturingworkcenter',
                                details: mfgRoutingSearchResult[mfgRoutingIndex].getValue({ name: 'manufacturingworkcenter' })
                            })*/
                            newTask['Machine'] = mfgRoutingSearchResult[mfgRoutingIndex].getValue({ name: 'manufacturingworkcenter' });
                           /* log.debug({
                                title: 'PCT-FS-Machine',
                                details: newTask['Machine']
                            })*/
                            newTask['Duration'] = eval(mfgRoutingSearchResult[mfgRoutingIndex].getValue({ name: 'operationsequence' }) * parseInt(postQty))
                            newTask['PInternalId'] = pIntId;
                            newTask['OperationName'] = mfgRoutingSearchResult[mfgRoutingIndex].getValue({ name: 'operationname' });

                            intTaskid++;
                            newTasksCount++;
                            newTasks.push(newTask)
                        }

                    }
                }

            }

            // Manufacturing Operation Task Data Search
            var manufacturingoperationtaskSearchObj = search.create({
                type: "manufacturingoperationtask",
                filters:
                [
                   ["workorder.status","anyof","WorkOrd:A","WorkOrd:B"]
                ],
                columns:
                [
                   search.createColumn({
                      name: "internalid",
                      join: "predecessor",
                      label: "Pred ID"
                   }),
                   search.createColumn({name: "workorder", label: "Work Order"}),
                   search.createColumn({
                      name: "custbody_pct_priority",
                      join: "workOrder",
                      sort: search.Sort.DESC,
                      label: "Priority"
                   }),
                   search.createColumn({
                      name: "internalid",
                      sort: search.Sort.ASC,
                      label: "Internal ID"
                   }),
                   search.createColumn({
                      name: "internalid",
                      join: "workOrder",
                      label: "WrkID"
                   }),
                   search.createColumn({
                      name: "item",
                      join: "workOrder",
                      label: "Item"
                   }),
                   search.createColumn({
                      name: "statusref",
                      join: "workOrder",
                      label: "Status"
                   }),
                   search.createColumn({name: "name", label: "Operation Name"}),
                   search.createColumn({name: "manufacturingworkcenter", label: "Manufacturing Work Center"}),
                   search.createColumn({
                      name: "formulanumeric",
                      formula: "{manufacturingworkcenter.id}",
                      label: "WcId"
                   }),
                   search.createColumn({
                      name: "formulanumeric",
                      formula: "{remainingquantity}*{runrate}",
                      label: "Time To Complete"
                   }),
                   search.createColumn({name: "status", label: "Status"}),
                   search.createColumn({name: "startdate", label: "Start Date"}),
                   search.createColumn({name: "enddate", label: "End Date"}),
                   search.createColumn({name: "predecessor", label: "Predecessor"}),
                   search.createColumn({
                      name: "completedquantity",
                      join: "predecessor",
                      label: "Predecessor Completed Quantity"
                   }),
                   search.createColumn({name: "inputquantity", label: "Input Quantity"}),
                   search.createColumn({name: "completedquantity", label: "Completed Quantity"}),
                   search.createColumn({name: "runrate", label: "Run Rate (Min/Unit)"}),
                   search.createColumn({name: "setuptime", label: "Setup Time (Min)"}),
                   search.createColumn({name: "remainingquantity", label: "Remaining Quantity"}),
                   search.createColumn({
                      name: "sequence",
                      sort: search.Sort.ASC,
                      label: "Operation Sequence"
                   }),
                   search.createColumn({
                      name: "custrecord_pct_acme_resch_datetime",
                      join: "CUSTRECORD_PCT_ACME_MANUF_OP_TASK_LINK",
                      label: "Rescheduled Start Date/Time"
                   }),
                   search.createColumn({
                      name: "custrecord_pct_acme_resch_end_datetime",
                      join: "CUSTRECORD_PCT_ACME_MANUF_OP_TASK_LINK",
                      label: "Rescheduled End Date/Time"
                   })
                ]
             });
             var mfgOperationTaskSearchCount = manufacturingoperationtaskSearchObj.runPaged().count;
             //log.debug("PCT-FS","Manufacturing Operation Task result count"+mfgOperationTaskSearchCount);
       
            // mfgOperationTaskSearchCount = 2 //new line added
            var mfgOperationTaskSearchResult = manufacturingoperationtaskSearchObj.run().getRange({
                start: 0,
                end: mfgOperationTaskSearchCount
            });
            // if (mfgOperationTaskSearchCount > 0)
            // {
            //     for (var mfgOperationTaskIndex = 0; mfgOperationTaskIndex < mfgOperationTaskSearchCount; mfgOperationTaskIndex++)
            //     {
            //         var workOrderId = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({
            //             name: 'workorder'
            //         });
            //         log.debug({
            //             title: 'PCT-FS',
            //             details: 'Work Order Id:' + workOrderId
            //         });
            //     }
            // }
            var pctRecordArray = new Array();
            var gnattRecordArray = new Array();
            var taskCount = 0;
            if (parseInt(mfgOperationTaskSearchCount) > 0)
            {
                var currTasks = [];
                // For each search results row, create a pctRecord object and attach it to the pctRecordArray
                // log.debug({
                //     title: 'PCT-FS',
                //     details: start
                // });
                for (var mfgOperationTaskIndex = 0; mfgOperationTaskIndex < mfgOperationTaskSearchCount; mfgOperationTaskIndex++)
                {
                    if (blnAddFirst && newTasksCount > 0)
                    {
                        taskCount = mfgOperationTaskIndex + mfgRoutingSearchCount;
                    }
                    else
                    {
                        taskCount = mfgOperationTaskIndex;
                    }
                    var pctRecord = new Object();
                    pctRecord['id'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'internalid', join: 'workOrder' });
                    //   log.debug({ title: 'PCT-FS', details: 'ID=' + pctRecord['id'] });

                    pctRecord['wrkid'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'workorder' });
                    //   log.debug({ title: 'PCT-FS', details: 'WO=' + pctRecord['wrkid'] });

                    pctRecord['operation_id'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].id;
                    //   log.debug({ title: 'PCT-FS', details: 'operation_id =' + pctRecord['operation_id'] });

                    pctRecord['operation'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'name' });
                    //   log.debug({ title: 'PCT-FS', details: 'operation =' + pctRecord['operation'] });

                    pctRecord['pred'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getText({ name: 'predecessor' });
                    //  log.debug({ title: 'PCT-FS', details: 'pred =' + pctRecord['pred'] });

                    pctRecord['wcid'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getText({ name: 'manufacturingworkcenter' });
                    //  log.debug({ title: 'PCT-FS', details: 'wcid =' + pctRecord['wcid'] });

                    pctRecord['ttc'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'formulanumeric' });
                    //  log.debug({ title: 'PCT-FS', details: 'ttc =' + pctRecord['ttc'] });

                    pctRecord['psdt'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'custrecord_pct_acme_resch_datetime', join: 'CUSTRECORD_PCT_ACME_MANUF_OP_TASK_LINK' })
                    //  log.debug({ title: 'PCT-FS', details: 'psdt =' + pctRecord['psdt'] });

                    pctRecord['pedt'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'custrecord_pct_acme_resch_end_datetime', join: 'CUSTRECORD_PCT_ACME_MANUF_OP_TASK_LINK' });
                    //  log.debug({ title: 'PCT-FS', details: 'pedt =' + pctRecord['pedt'] });

                    pctRecord['ssdt'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'custrecord_pct_acme_resch_datetime', join: 'CUSTRECORD_PCT_ACME_MANUF_OP_TASK_LINK' });
                    //  log.debug({ title: 'PCT-FS', details: 'ssdt =' + pctRecord['ssdt'] });

                    pctRecord['sedt'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'custrecord_pct_acme_resch_end_datetime', join: 'CUSTRECORD_PCT_ACME_MANUF_OP_TASK_LINK' });
                    // log.debug({ title: 'PCT-FS', details: 'sedt =' + pctRecord['sedt'] });

                    pctRecord['wrkpr'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'custbody_pct_priority', join: 'workOrder' });
                    // log.debug({ title: 'PCT-FS', details: 'wrkpr =' + pctRecord['wrkpr'] });

                    pctRecord['opseq'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'sequence' });
                    // log.debug({ title: 'PCT-FS', details: 'opseq =' + pctRecord['opseq'] });

                    var pred = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'internalid', join: 'predecessor' });
                    // log.debug({ title: 'PCT-FS', details: 'pred=' + pred });

                    if (pred == "")
                    {
                        pred = -1;
                    }
                    var task = new Object;
                    task['JInternalId'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'internalid' }),
                        task['InternalId'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].id,
                        task['Machine'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'manufacturingworkcenter' }),
                        task['Duration'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'formulanumeric' }),
                        task['PInternalId'] = pred,
                        task['OperationName'] = mfgOperationTaskSearchResult[mfgOperationTaskIndex].getValue({ name: 'name' })

                    currTasks.push(task);
                    pctRecordArray[taskCount] = pctRecord;

                }
                /*log.debug({
                    title: ' PCT-FS ',
                    details: 'Records=' + JSON.stringify(pctRecordArray)
                });
                log.debug({
                    title: "PCT-FS",
                    details: "Task Count 1 : "+taskCount
                })

                log.debug({ title: 'PCT-FS', details: 'PCT Record Array '+ pctRecordArray.length });*/

                if (parseInt(newTasksCount) > 0)
                {
                    for (var mfgRouting_index = 0; mfgRouting_index < mfgRoutingSearchCount; mfgRouting_index++)
                    {
                        if (!blnAddFirst)
                        {
                          var  taskCnt = parseInt(mfgRouting_index) + parseInt(mfgOperationTaskSearchCount);
                            /*log.debug({
                                title: "PCT-FS",
                                details: "IN BLIND_FIRST IF CONDITION & TASK COUNT : "+taskCnt
                            })*/
                        }
                        else
                        {
                           var taskCnt = parseInt(mfgRouting_index);
                           /* log.debug({
                                title: "PCT-FS",
                                details: "IN BLIND_FIRST ELSE CONDITION & TASK COUNT : "+taskCnt
                            })*/
                        }
                       /* log.debug({
                            title: "PCT-FS",
                            details: "Task Count 2 : "+ taskCount
                        })
                        log.debug({
                            title: "PCT-FS",
                            details: "Current Count : "+currTasks.length
                        })*/
                        var pctNewRecord = new Object();
                        pctNewRecord['operation'] = mfgRoutingSearchResult[mfgRouting_index].getValue({ name: 'operationname' });
                        if (mfgRouting_index == 0)
                        {
                            pctNewRecord['pred'] = "";
                        }
                        else
                        {
                            pctNewRecord['pred'] = mfgRoutingSearchResult[mfgRouting_index - 1].getValue({ name: 'operationname' });
                        }
                        pctNewRecord['wrkid'] = "New Work order";
                        pctNewRecord['wcid'] = mfgRoutingSearchResult[mfgRouting_index].getText({ name: 'manufacturingworkcenter' });
                        pctNewRecord['ttc'] = eval(mfgRoutingSearchResult[mfgRouting_index].getValue({ name: 'runrate' }) * parseInt(postQty))
                        pctNewRecord['psdt'] = "";
                        pctNewRecord['pedt'] = "";
                        // Attach the pctRecord object to the pctRecord array
                        pctRecordArray[taskCnt] = pctNewRecord;

                    }
                }
                /*log.debug({
                    title: ' PCT-FS ',
                    details: 'Records=' + JSON.stringify(pctRecordArray)
                });
                log.debug({ title: 'PCT-FS', details: 'PCT Record Array '+ pctRecordArray.length });*/
                if (newTasksCount > 0)
                {
                    if (blnAddFirst)
                    {
                       var Tasks = newTasks.concat(currTasks);
                    }
                    else
                    {
                        var Tasks = currTasks.concat(newTasks);
                    }
                }
                else
                {
                   var Tasks = currTasks;
                }
            }
            /*log.debug({
                title: 'PCT-FS',
                details: 'Current Method:' + context.request.method
            });*/
            var customPlugin = plugin.loadImplementation({
                type: 'customscript_pct_fs_calculate_duration'
            });
            if (context.request.method === 'GET')
            {
               /* log.debug({
                    title: 'PCT-FS',
                    details: 'Current Record:' + JSON.stringify(pctRecordArray)
                });*/
                var recordArrayField = Form.addField({
                    id: 'custpage_pctrecordarray',
                    type: serverWidget.FieldType.LONGTEXT,
                    label: 'Text'
                });

                recordArrayField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                });
                recordArrayField.defaultValue = JSON.stringify(pctRecordArray);
                if (parseInt(clientFileId) > 0)
                {
                    Form.clientScriptFileId = clientFileId;
                }
                context.response.writePage(Form);
            } else
            {
                var getMethodField = Form.addField({
                    id: 'custpage_get_method',
                    label: 'Text',
                    type: serverWidget.FieldType.TEXT,

                })
                getMethodField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                })

                getMethodField.defaultValue = 'POST';

                var selectedDate = context.request.parameters.custpage_date;
                /*log.debug({
                    title: 'PCT-LOG',
                    details: 'Selected Date  ' + selectedDate
                })*/

                var itemSelectField = Form.addField({
                    id: 'custpage_item_store',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Text'
                });
                itemSelectField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                })
                itemSelectField.defaultValue = postItemId;
                var dateSelectField = Form.addField({
                    id: 'custpage_date_store',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Text'
                });
                dateSelectField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                });

                dateSelectField.defaultValue = selectedDate;
                var QuantitySelectField = Form.addField({
                    id: 'custpage_quantity_store',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Text'
                });
                QuantitySelectField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                })
                QuantitySelectField.defaultValue = postQty;
                var StartTimeField = Form.addField({
                    id: 'custpage_starttime_store',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Text'
                });
                StartTimeField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                })
                StartTimeField.defaultValue = postStartTime;
                var EndTimeField = Form.addField({
                    id: 'custpage_endtime_store',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Text'
                });
                EndTimeField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                })
                EndTimeField.defaultValue = postEndTime;

                var Movefirst = Form.addField({
                    id: 'custpage_movefirst_store',
                    type: serverWidget.FieldType.CHECKBOX,
                    label: 'Text'
                });
                Movefirst.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                })
                /*log.debug({
                    title: 'blnAddFirst',
                    details: blnAddFirst
                })*/
                //Movefirst.defaultValue = blnAddFirst;

                /*log.debug({
                    title: 'PCT-FS',
                    details: 'Post Data:(Item:' + postItemId + ',Quantity:' + postQty + ',Move First:' + postMoveFirst + ',Date:' + postDate + ',Start Time:' + postStartTime + ',End Time:' + postEndTime + ')'
                });*/
                if (postStartTime == '')
                {
                    postStartTime = "8:00 AM"
                }

                if (postEndTime == '')
                {
                    postEndTime = "5:00 PM"
                }
               /* log.debug({
                    title: 'PCT-FS',
                    details: 'Before Formatted Date:' + postDate
                });
                log.debug({
                    title: 'PCT-FS',
                    details: 'Before Type Formatted Date:' + typeof (postDate)
                });*/
                if (postDate != '')
                {
                    var dateObj = postDate.split("-");
                    postDate = dateObj[1] + "/" + dateObj[2] + "/" + dateObj[0];
                   /* log.debug({
                        title: 'PCT-FS',
                        details: 'Formatted Date:' + postDate
                    });*/
                }
                else
                {
                    postDate = '';
                }

                var recordArrayField = Form.addField({
                    id: 'custpage_pctrecordarray',
                    type: serverWidget.FieldType.LONGTEXT,
                    label: 'Text'
                });
               /* log.debug({
                    title: 'PCT-FS',
                    details: 'Send Data:' + Tasks
                });/*/
                log.audit({
                    title: 'postDate ='+postDate+ 'postStartTime ='+postStartTime + ' postEndTime='+postEndTime,
                    details: 'Tasks ='+ JSON.stringify(Tasks)
                })
                var schedule = customPlugin.calculateDuration(Tasks, postDate, postStartTime, postEndTime);
                //log.debug({ title: 'PCT-FS', details: 'Plugin Details' + JSON.stringify(schedule) });
                var ScheduleLength = schedule.length;
                /*log.debug({ title: 'PCT-FS', details: 'Schedule Length' + ScheduleLength });
                log.debug({ title: 'PCT-FS', details: 'PCT Record Array Length' + pctRecordArray.length });
              
                log.debug({
                    title: "PCT-FS",
                    details: "Schedule" + JSON.stringify(schedule[ScheduleLength - 1])
                });
                log.debug({
                    title: "PCT-FS",
                    details: "PCT Record Array " + JSON.stringify(pctRecordArray[pctRecordArray.length - 1])
                });*/
                var jEndDate = null;
                for (var schedule_index = 0; schedule_index < ScheduleLength; schedule_index++)//new tasks are already in the schedule
                {
                    //var pctRecord = new Object();
                    //pctRecord['operation'] = schedule[i].JInternalId;
                   /* log.debug({
                        title: "PCT-FS",
                        details: "I :"+schedule_index
                    })
                    log.debug({
                        title: "PCT-FS",
                        details: "Start Date "+schedule[schedule_index].StartDate
                    })*/
                  
                        pctRecordArray[schedule_index]['ssdt'] = schedule[schedule_index].StartDate;
                    pctRecordArray[schedule_index]['sedt'] = schedule[schedule_index].EndDate;
                    pctRecordArray[schedule_index]['downtime'] = schedule[schedule_index].downtime;

                    // Attach the pctRecord object to the pctRecord array
                    //pctRecordArray[i] = pctRecord;
                    if (schedule[schedule_index]['JInternalId'] == "1")//this is the new task
                    {
                        jEndDate = schedule[schedule_index]['JEndDate'];
                    }

                }
                if (jEndDate != null)
                {
                    /*log.debug({
                        title: 'PCT-FS',
                        details: 'End Date Null'
                    });*/
                    //var alertfield=Form.addField('pct_alert', 'inlinehtml');
                    //alertfield.setDefaultValue('<SCRIPT>alert("The required number of parts can be produced by '+ jEndDate+'")</SCRIPT>')

                }
                recordArrayField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.HIDDEN
                });
                recordArrayField.defaultValue = JSON.stringify(pctRecordArray);
                if (parseInt(clientFileId) > 0)
                {
                    Form.clientScriptFileId = clientFileId;
                }
                var gnattChartData = customPlugin.gantt_structure(pctRecordArray);
               // log.debug({ title: 'PCT-FS', details: 'Gnatt Structure:' + JSON.stringify(gnattChartData) });
                gnattChartData = JSON.stringify(gnattChartData);
                gnattChartData = gnattChartData.replace(/"(\w+)"\s*:/g, '$1:');
                gnattChartData = gnattChartData.replace(/"[n][e][w]\s[D][a][t][e]\S[^\n]/g, 'new Date(').replace(/[^\n]"\S"/g, '")');
                gnattChartData = 'var ganttData =' + gnattChartData + ';';
                postStartTime = '08:00 AM';
                postEndTime = '05:00 PM';
                var value = {
                    interval: '01:00:00',
                    startTime: postStartTime,
                    endTime: postEndTime
                };
                //var intervals = customPlugin.showTimeIntervals(value);
                // log.debug({ title: 'PCT-FS', details: 'Intervals:' + intervals });
                // var intervalsHeader = 'var workHours = [' + intervals + '];';
                // var locationName = ' ';
                // var subsidiaryName = ' ';
                // if (parseInt(userLocation) != 0)
                // {
                //     var searchtype = 'location';
                //     locationName = customPlugin.nameSearch(searchtype, userLocation);
                // }
                // if (parseInt(userSubsidiary) != 0)
                // {
                //     var searchtype = 'subsidiary';
                //     subsidiaryName = customPlugin.nameSearch(searchtype, userSubsidiary);
                // }
                // log.debug({ title: 'PCT-FS', details: 'Location Name:' + locationName });
                // log.debug({ title: 'PCT-FS', details: 'Subsidiary Name:' + subsidiaryName });
                // var currentUserData = 'var headerData ={"location":"' + locationName + '","subsidiary": "' + subsidiaryName + '"};';
                // var fileObj = file.create({
                //     name: 'data.json',
                //     fileType: file.Type.JSON,
                //     contents: intervalsHeader + '\n' + currentUserData + '\n' + gnattChartData
                // });
                var intervals = customPlugin.showTimeIntervals(value);
               // log.debug({ title: 'PCT-FS', details: 'Intervals:' + intervals });
                var intervalsHeader = 'var workHours = [' + intervals + '];';
                var currentUserData = 'var headerData ={"location":"' + userLocation + '","subsidiary": "' + userSubsidiary + '"};';
                var fileObj = file.create({
                    name: 'data.json',
                    fileType: file.Type.JSON,
                    contents: intervalsHeader + '\n' + currentUserData + '\n' + gnattChartData
                });
                var mainFolderId = 0;
                var mainFolderSearch = search.create({
                    type: "folder",
                    filters:
                        [
                            ["name", "is", "Finite Scheduling"]
                        ]
                });
                var mainFolderSearchCount = mainFolderSearch.runPaged().count;
                //log.debug("PCT-FS", 'Main Folder Count:' + mainFolderSearchCount);
                var mainFolderSearchResult = mainFolderSearch.run().getRange({
                    start: 0,
                    end: mainFolderSearchCount
                });
                if (mainFolderSearchCount > 0)
                {
                    for (var mainFolderIndex = 0; mainFolderIndex < mainFolderSearchCount; mainFolderIndex++)
                    {
                        mainFolderId = mainFolderSearchResult[mainFolderIndex].id;
                       /* log.debug({
                            title: 'PCT-FS',
                            details: 'Main Folder Id:' + mainFolderId
                        });*/
                    }
                }
                if (mainFolderId > 0)
                {
                    var dataFolderId = 0;
                    var dataFolderSearch = search.create({
                        type: "folder",
                        filters:
                            [
                                ["name", "is", "Gnatt Data"],
                                "AND",
                                ["parent", "anyof", mainFolderId]
                            ]
                    });
                    var dataFolderSearchCount = dataFolderSearch.runPaged().count;
                    //log.debug("PCT-FS", 'Data Folder Count:' + dataFolderSearchCount);
                    var dataFolderSearchResult = dataFolderSearch.run().getRange({
                        start: 0,
                        end: dataFolderSearchCount
                    });
                    if (dataFolderSearchCount > 0)
                    {
                        for (var dataFolderIndex = 0; dataFolderIndex < dataFolderSearchCount; dataFolderIndex++)
                        {
                            dataFolderId = dataFolderSearchResult[dataFolderIndex].id;
                            /*log.debug({
                                title: 'PCT-FS',
                                details: 'Data Folder Id:' + dataFolderId
                            });*/
                        }
                    }
                    if (dataFolderId > 0)
                    {
                        fileObj.folder = dataFolderId;
                        var fileId = fileObj.save();
                    }
                }
                context.response.writePage(Form);
            }
        }

        return {
            onRequest: onRequest
        };

    });