/**
 * // To update the schedule time or to create schedule timimg record if not present
 *@NApiVersion 2.1
 *@NScriptType MapReduceScript
 Date: 3rd March 2021

 */
 define(['N/log','N/record','N/runtime','N/file','N/format'], function(log,record,runtime,file,format) {

    function getInputData() {
        log.debug({
            title: 'In scheduled function'
        })
        var data_obj = runtime.getCurrentScript().getParameter({
            name: 'custscript_pct_fs_mapreduce_param'
        })
        log.debug({
            title: 'data_obj =',
            details: parseInt(data_obj)
        })
    //    var file_id = data_obj;
        var file_id = file.load({
            id: 6947
        })
        log.debug({
            title:'file_id',
            details: file_id
        })
        var file_content = file_id.getContents()
        log.debug({
            title:'file_content',
            details: file_content
        })
        
       // var data_prev = file_id.getValue();
	  file_content = file_content.slice(0, -1);
      file_content = file_content.split("=");
      file_content = file_content[3];
      log.debug({
            title:'PCT-FS-MR',
            details: 'Main Data:'+file_content
        });
      file_content = file_content.replace(/"[)]/g,'"');
      file_content = file_content.replace(/[n][e][w]\s[D][a][t][e]\S[^\n]/g,'"');
      file_content = file_content.replace(/([{,])(\s*)([A-Za-z0-9_\-]+?)\s*:/g, '$1"$3":');
      file_content = file_content.replace(/[:][[][{]/g, ':"[{');
	  file_content = file_content.replace(/[}][]]}]/g, '}]"}');
      file_content = file_content.replace(/"[[]/g, '[');
      file_content = file_content.replace(/]"/g, ']');
      
        log.debug({
            title:'PCT-FS-MR',
            details: 'Filter Data:'+file_content
        });


       //var dataprev = JSON.stringify(file_content);
     var updated_file = JSON.parse(file_content);
       //var updated_file_len= file_content.length;
       log.debug({
        title: 'PCT-FS-MR',
        details: 'Data:'+updated_file
         });
        // log.debug({
        //  title: 'PCT-FS-MR',
        //  details: 'Data Length:'+typeof(updated_file)
        //   });
        
        var updated_file_len= updated_file.length;
        var dataSet = new Array(); 
        for (updatedfile_index =0 ; updatedfile_index < updated_file_len; updatedfile_index++)
        {
            
            dataSet.push(updated_file[updatedfile_index]);
            
        }
        return dataSet;
        
    }

    function map(context) 
    {
        log.debug({
            title: 'Map',
            details:'Map Data = '+context.value
        })

         var data=context.value;
         
        // var dataprev = JSON.parse(context.value);
        //  log.debug('context', context.value);
        // var data=context.value;
        
        // var data_key = data.id;
        // log.debug({
        //     title: 'data_key',
        //     details: data_key
        // })
        context.write(data)
        
        
        // return data_len;
        
    }
    function reduce(context)
    {
        log.debug({
            title: 'reduce'
        })
        var data= context.key;
        log.debug({
            title: 'PCT_LOG',
            details: 'Data = '+(JSON.parse(data).id)
        })
        var reduce_data = JSON.parse(data);
        // var data_len = data.length;
        // log.debug('data_len', data_len);
        // // log.debug('reduce data len', datalen);
        var data_series=reduce_data.series;
        var dataseries_len = data_series.length;
        if( dataseries_len > 0)
	    {
		    for(var dataseries_index = 0; dataseries_index < dataseries_len; dataseries_index++)
		    {
                var manuf_op_task_id = data_series[dataseries_index].id;
                log.debug({
                    title: 'manuf_op_task_id',
                    details: manuf_op_task_id
                })
                

                var sch_start_time = data_series[dataseries_index].start;
                log.debug({
                    title: 'sch_start_time',
                    details: sch_start_time
                })
                
			
			    var converted_sch_start_time = format.parse({
                    value: sch_start_time,
                    type:'datetimetz'
                })
                
			
			    var sch_end_time = data_series[dataseries_index].end;
                log.debug({
                    title: 'sch_end_time',
                    details: sch_end_time
                })
                
			
			    var converted_sch_end_time = format.parse({
                    value: sch_end_time,
                    type: 'datetimetz'
                })
                
			
                var manuf_op_task_rec = record.load({
                    type: 'manufacturingoperationtask',
                    id: manuf_op_task_id
                }) 
			
                var sch_timing_rec_count = manuf_op_task_rec.getLineCount({
                    sublistId: 'recmachcustrecord_pct_acme_manuf_op_task_link'
                }) 
                
			    
                if(sch_timing_rec_count == 0)
			    {
                    var create_sch_timing_rec = record.create({
                        type: 'customrecord_pct_acme_manuf_sch_time'
                    })
                    
                    create_sch_timing_rec.setValue({
                        fieldId: 'custrecord_pct_acme_resch_datetime',
                        value: converted_sch_start_time
                    })
                    create_sch_timing_rec.setValue({
                        fieldId: 'custrecord_pct_acme_resch_end_datetime',
                        value: converted_sch_end_time
                    })
                    create_sch_timing_rec.setValue({
                        fieldId: 'custrecord_pct_acme_manuf_op_task_link',
                        value: manuf_op_task_id
                    }) 
                    
                    create_sch_timing_rec.save({
                        enableSourcing: true
                    })
                    
			    }
			    else
			    {
                    var sch_timing_rec_id = manuf_op_task_rec.getSublistValue({
                        sublistId: 'recmachcustrecord_pct_acme_manuf_op_task_link',
                        fieldId: 'id',
                        line: 0
                    })
                    // log.debug({
                    //     title: 'sch_timing_rec_id',
                    //     details: sch_timing_rec_id
                    // })
                    
                    
                    var load_sch_timimg_rec = record.load({
                        type: 'customrecord_pct_acme_manuf_sch_time',
                        id: sch_timing_rec_id
                    })
                    
                    load_sch_timimg_rec.setValue({
                        fieldId: 'custrecord_pct_acme_resch_datetime',
                        value: converted_sch_start_time
                    })
                    load_sch_timimg_rec.setValue({
                        fieldId: 'custrecord_pct_acme_resch_end_datetime',
                        value: converted_sch_end_time
                    })
                    


                    load_sch_timimg_rec.save({
                        enableSourcing: true
                    })
                    
			    }
		    }
            
	    }

    }

    /*function summarize(context)
    {
        log.debug({
            title: 'dataprev =',
            details: dataprev 
        })

        var totalItemsProcessed = 0;
        context.output.iterator().each(function () { totalItemsProcessed++; });
        var summaryMessage = "dataprev: " + context.dataprev ;
        log.debug({ title: 'Summary of usase', details: summaryMessage });
    }*/
    return {
        getInputData: getInputData,
        map: map,
        reduce: reduce
        //summarize: summarize
    }
});
