var ganttData = [
	{
		id: 1, name: "", series: [
			{ name: "Planned", start: new Date(2020, 00, 01, 8, 00), end: new Date(2020, 00, 03, 10, 00), color: "#1E90FF" },
			{ name: "Actual", start: new Date(2020, 00, 02, 10, 00), end: new Date(2020, 00, 05, 11, 00), color: "#B0E0E6" }
		]
	},
	{
		id: 1, name: "Feature 1", series: [
			{ name: "Planned", start: new Date(2020, 00, 01, 8, 00), end: new Date(2020, 00, 03, 10, 00), color: "#1E90FF" },
			{ name: "Actual", start: new Date(2020, 00, 02, 10, 00), end: new Date(2020, 00, 05, 11, 00), color: "#B0E0E6" }
		],
	}
];